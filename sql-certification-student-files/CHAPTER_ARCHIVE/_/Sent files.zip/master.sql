--      Constraint Type Single Table: constraint is a rule on 1 or more columns
--              PRIMARY KEY: must be unique and not null
--              UNIQUE:      must be unique         
--              NOT NULL:    cannot be null
--                  What does null mean: unknown
--              CHECK: 
--              DEFAULT:
--       Constraint type Two Tables
--              FOREIGN KEY:see master
-- ************************************************************


create table students
            (
                s_id integer,
                student_name  varchar2(25)
             );
select * from user_constraints; -- add constraint after table creation
--PRIMARY KEY
--add constraint after table creation
--typically an afterthought
alter table students add primary key(s_id);                     -- system gives name
alter table students add constraint stud_pk primary key(s_id);  -- user(me) names it
alter table students modify s_id primary key;                   -- sys gives name
alter table students rename constraint SYS_C007570 to STUD_PK;  -- rename a constraint

-- add constraint after table creation   
-- typical best practice

-- UNIQUE
-- same pattern of techniques used in primgary key works for unique sonstraint

-- NOT NULL 
-- Next line does not work per Oracle
-- alter table students add not null(student_name);

alter table students modify student_name not null;
alter table students modify student_name constraint stud_name_nn not null;

-- FOREIGN KEY
-- Creates a parent child relationship, it connects to the primary key in the parent table
-- and prevents orphans.  It is created on the child table and points to the primary key of the parent
-- primary key on parent must exist


-- add constraint at time of table creation
-- typical best practice

-- Contraints Created at time of table creation

--Create inline constraints at time of table creation
 create table cruises
(
        cruise_id number constraint cruise_id_pk primary key,
        cruise_name varchar2(30) not null,
        cruise_number integer unique,
        destination varchar2(50) check
        (destination in ('Hawaii','Bahamas','Bermuda',
        'Mexico','Day at Sea')),
        start_date date default sysdate,
        end_date date
    );

--Create out of line constraints at time of table creation
select * from user_constraints where table_name = 'CRUISES';
drop table cruises;
create table cruises
(
        cruise_id number,
        cruise_name varchar2(30) not null,
        cruise_number integer,
        destination varchar2(50),
        start_date date default sysdate,
        end_date date,
        constraint cruise_pk primary key (cruise_id),
        -- NOT VALID MUST BE INLINE constraint cruise_name_nn not null (cruise_name),
        constraint cruise_num_u unique (cruise_number),
        constraint destination_ck check (destination IN  ('Hawaii','Bahamas','Bermuda','Mexico','Day at Sea'))
        -- default must also be inline
        );
       