set verify off
DEFINE sysPassword = "&1"
DEFINE systemPassword = "&2"
@C:\oraclexe\app\oracle\product\11.2.0\server\config\scripts\CloneRmanRestore.sql
@C:\oraclexe\app\oracle\product\11.2.0\server\config\scripts\cloneDBCreation.sql
@C:\oraclexe\app\oracle\product\11.2.0\server\config\scripts\postScripts.sql
exit
