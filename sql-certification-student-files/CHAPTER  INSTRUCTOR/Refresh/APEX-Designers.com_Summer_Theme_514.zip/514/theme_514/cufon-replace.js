Cufon.replace('h1 span em', { fontFamily: 'wickhop handwriting',textShadow:'1px 1px #25469d' });
Cufon.replace('.sidebar  h3', { fontFamily: 'wickhop handwriting',textShadow:'1px 1px #346dbf' });
Cufon.replace('.sidebaralt1  h3', { fontFamily: 'wickhop handwriting',textShadow:'1px 1px #7caa1e' });

