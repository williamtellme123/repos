-- =============================================================================
-- Chapter 6 Using Single-Row Functions to Customize Output
-- =============================================================================
/* -----------------------------------------------------------------------------
  Characteristics of functions
    1. Accept incoming values or parameters
    2. Perform a task on the incoming values
    3. Return a single answer as a result

  Functions can be used anywhere expressions can be used
    1. SELECT statement's SELECT list and WHERE clause (order by?)
    2. INSERT statement's list of values
    3. UPDATE statement's SET clause and WHERE clause
    4. DELETE statement's WHERE clause
------------------------------------------------------------------------------*/

/* -----------------------------------------------------------------------------
  Concatenation p 216-7
    CONCAT(s1,s2)
      s1 and s2 are both strings
    double pipe: ||  
------------------------------------------------------------------------------*/
-- use books
SELECT 'Hello' || 'World' FROM dual;

SELECT concat('Hello ', 'World') FROM dual;
-- concat only has two parameters, so we need to nest it

/* -----------------------------------------------------------------------------
  Converting case:
    UPPER (s1)
      returns string s1 in upper case
    LOWER (s1)
      returns string s1 in lower case
    INITCAP
      returns string s1 in mixed case string with the first letter capitalized 
      and the rest lower case
------------------------------------------------------------------------------*/
SELECT ('NAPoleAN boNaParT') FROM dual;
-- use cruises
  
-- INITCAP 

-- We have to 'escape' the ' mark in o'brian's name
-- select initcap('red o'brian') from dual;

-- One reason for using alias is to make the output more readable

CREATE OR REPLACE VIEW vw_customers AS 
  SELECT *
 FROM customers; 
 
SELECT fullname, full_address FROM vw_customers;

/* -----------------------------------------------------------------------------
  LENGTH (s1)
    returns the number of characters in string s1
------------------------------------------------------------------------------*/
SELECT initcap(firstname || ' ' || lastname) fullname,
  length(firstname || ' ' || lastname) name_length FROM customers;
  
-- use cruises
-- How long are the ship names?
SELECT ship_name, LENGTH(ship_name) FROM ships;
-- How long are the employee's names?

/* -----------------------------------------------------------------------------
  LPAD (s1,n,s2) p 217 pads s1 to the left n characters with s2
  RPAD (s1,n,s2) p 217 pads s1 to the right n characters with s2
------------------------------------------------------------------------------*/
SELECT lpad('Chapter 1', 30) FROM dual;
--truncates if too long

-- First string can't be null
SELECT rpad('', 30, '.') FROM dual;


/* -----------------------------------------------------------------------------
-- TRIM & RTRIM removes specified characters from an input string
-- P 218
------------------------------------------------------------------------------*/
SELECT ('       test string       ') from dual;
SELECT ('........test string---------') from dual;

SELECT ('-------test string---------') FROM dual;
-- Default if first keyword omitted is BOTH

/* -----------------------------------------------------------------------------
  INSTR(s1, s2, pos,n) - p 220
    returns the location of the string searched for(S2) inside
    the string being searched(s1). Searches from front
------------------------------------------------------------------------------*/
SELECT instr('Mississippi', 'is') FROM dual;
-- pos is the starting position from which to find s2
-- n is the number of the occurance
-- if pos is negative, searches from the back
-- Won't find anything if pos is > length

/* -----------------------------------------------------------------------------
  SUBSTR(s, pos, len) len is optional p 220
------------------------------------------------------------------------------*/
SELECT substr('Name: Mark Kennedy', 1) FROM dual;
-- what is the sub string from postion 7 to the end?

-- Start with postion 7 and return a string 4 characters long


/* -----------------------------------------------------------------------------
  soundex - p 221
------------------------------------------------------------------------------*/
SELECT soundex('Franklin') FROM dual;


/* -----------------------------------------------------------------------------
  Number functions - page 223 - 225
    ROUND
    TRUNC
    MOD
    REMAINDER
------------------------------------------------------------------------------*/
-- Exploring the rounding function
SELECT round(1234.5678), round(1234.5678, 0) FROM dual;

SELECT cost, retail, retail-cost as profit, 
      (retail/cost-1)*100 as percent_profit FROM books;

-- comparing round and trunc
SELECT trunc(1234.5678), round(1234.5678) FROM dual;

-- p224 comparing remainder and mod
-- mod works exactly like a remainder in mathematical division


/* -----------------------------------------------------------------------------
  not in book
------------------------------------------------------------------------------*/
SELECT floor(2.99), ceil(2.99) FROM dual;
SELECT floor(-2.99), ceil(-2.99) FROM dual;
SELECT floor(3141.7252), ceil(3141.7252) FROM dual;
SELECT abs(-1.75) FROM dual;

-- Can use with dates, numbers or strings.
-- If null is anywhere in the list, it returns null
SELECT least(0,1,2,3, -1) FROM dual;
SELECT least('Amelia', 'Fred', 'betty', 'david') FROM dual;
SELECT greatest(0,1,2,3, -1) FROM dual;
SELECT greatest('Amelia', 'Fred', 'betty', 'david') FROM dual;

/* -----------------------------------------------------------------------------
  Date and Time functions - page 225 - 230
  SYSDATE
  ROUND
  TRUNC
------------------------------------------------------------------------------*/
SELECT sysdate FROM dual;
-- rounding sysdate after noon returns tomorrow
SELECT sysdate, round(sysdate) FROM dual;

-- format strings are on page 242-243
SELECT sysdate, round(sysdate, 'MM') FROM dual;



-- round accepts timestamps, but returns a date datatype
SELECT systimestamp today,
  ROUND(systimestamp),
  ROUND(systimestamp, 'HH'),
  ROUND(systimestamp, 'HH24')
FROM dual;


/* -----------------------------------------------------------------------------
  NEXT_DAY, LAST_DAY
------------------------------------------------------------------------------*/
SELECT sysdate, next_day(sysdate, 'MONDAY') FROM dual;

-- last_day returns the last day of the month in which a given date falls
SELECT sysdate, last_day(sysdate) FROM dual;

-- find the third wednesday of any month

/* -----------------------------------------------------------------------------
  ADD_MONTHS adds a number of months to a date
------------------------------------------------------------------------------*/
SELECT add_months(SYSDATE, 7) FROM dual;

SELECT * FROM orders;
SELECT months_between(sysdate, '31-MAR-03') FROM dual; -- 147.9

savepoint testdates;
UPDATE orders SET orderdate = add_months(orderdate, 146),
                   shipdate = add_months(shipdate, 146);
rollback to testdates;
commit;

-- to add days, just use math

/* -----------------------------------------------------------------------------
  MONTHS_BETWEEN(d1,d2) 
    d1 is the later date, d2 the earlier date
------------------------------------------------------------------------------*/
SELECT months_between(SYSDATE, '04-JUL-1776') FROM dual;

/* -----------------------------------------------------------------------------
  NUMTOYMINTERVAL
  NUMTODSINTERVAL
------------------------------------------------------------------------------*/
-- use books
select * from testintervals;
-- 27 months is 2 years and 3 months:
SELECT numtoyminterval(27, 'MONTH') from dual;
  
SELECT numtodsinterval(36,'HOUR') FROM DUAL;


/* -----------------------------------------------------------------------------
  NVL(e1, e2) - page 230 - 231
    e1 and e2 are expressions of the same datatype
    Returns e1 is NULL, returns e2, else returns e1
  NVL2(e1, e2, e3 ) - NOT IN BOOK, adds support for non null values
      e1, e2, e3 are all expressions of the same datatype
      Returns e2 if e1 is not null
      Returns e3 if s1 is null.
------------------------------------------------------------------------------*/
-- Use books
SELECT NVL(NULL,0) FIRST_ANSWER,
  14+NULL-4 SECOND_ANSWER,
  14+NVL(NULL,0)-4 THIRD_ANSWER
FROM DUAL;

-- REPLACING A NULL VALUE WITH ONE YOU CAN WORK WITH
SELECT * FROM orders WHERE shipdate IS null;
SELECT order#, orderdate, shipdate
  FROM orders ORDER BY shipdate DESC;

-- Problems with nvl:
-- Can't use text if datatype is not text
-- Can't replace NON-NULL values
  

/* -----------------------------------------------------------------------------
  COALESCE (exp_list) NOT IN BOOK - Generraliztion of NVL
    Returns the first non null value in the expression list
    exp_list - comma separated list of expressions of the similar datatypes
------------------------------------------------------------------------------*/
SELECT COALESCE(NULL, 64*4, 135/3) FROM dual;
SELECT COALESCE(NULL, 'test', NULL) FROM dual;
SELECT COALESCE(SYSDATE, SYSTIMESTAMP) FROM dual;
SELECT COALESCE(NULL, NULL, to_char(SYSDATE), 'TEST') FROM dual;
-- Must have the same datatype
SELECT COALESCE(sysdate, 64*4, 'test') FROM dual; -- FAILS

/* -----------------------------------------------------------------------------
  DECODE (e, search_e, d) - p231 
    Replacing data in table with something more meaningful 
------------------------------------------------------------------------------*/
SELECT customer#, address, city, state from customers;
SELECT customer#, address, city, 
  decode(state, 'CA', 'California',
                'FL', 'Florida',
                'NY', 'New York',
                'TX', 'Texas',
                'GA', 'Georgia',
                'NJ', 'New Jersey',
                'Other') as new_state
  FROM customers;

-- default if omitted will be null
 -- cruises database

/* -----------------------------------------------------------------------------
  CASE e1 WHEN c1 THEN r1 ... ELSE default - p232
------------------------------------------------------------------------------*/
-- CASE is similar to DECODE but a little more flexible
SELECT customer#, address, city, state, CASE state
        WHEN 'CA' THEN 'California'
        WHEN 'FL' THEN 'Florida'
        WHEN 'NY' THEN 'New York'
        WHEN 'TX' THEN 'Texas'
        WHEN 'GA' THEN 'Georgia'
        WHEN 'NJ' THEN 'New Jersey'
        ELSE 'Other' END AS new_state
  FROM customers;

-- cruises database
-- this is a numeric comparison because capacity is a number datatype

-- This is a boolean comparison. You can use IN or BETWEEN as well

SELECT * FROM scores;
INSERT INTO scores (score_id, test_score) VALUES (4,76);
INSERT INTO scores (score_id, test_score) VALUES (5,90);
INSERT INTO scores (score_id, test_score) VALUES (6,70);
-- Use case when then else to assign a letter grade for test_score
-- A for 90+, B for 80-89, ... F for < 60


/* -----------------------------------------------------------------------------
   NULLIF( expr1, expr2 ) p233 
     NULLIF returns null if both parameters are the same else return the first parameter
     expr1 and expr2 must be same datatype.
     expr1 can be an expression that evaluates to NULL, but it can not be the literal NULL.
     if expr1, expr2 are the same return null
     if expr1, expr2 different return expr1  
------------------------------------------------------------------------------*/
SELECT nullif(round(4.549234,2),trunc(4.549234,2))  FROM dual;

SELECT * FROM scores;
-- if expr1 and expr2 the same then return null
  

UPDATE scores SET updated_test_score = 72 WHERE score_id = 4;


/* -----------------------------------------------------------------------------
  nls_parameters - p 237  NLS means National Language Support
    Parameters that are set when Oracle is installed and can be changed by the 
    SQL programmer for adhoc data conversion.
    nls_parms are used in several conversion functions
------------------------------------------------------------------------------*/
select * from nls_session_parameters;
select * from nls_database_parameters;
-- NLS_NUMERIC_CHARACTERS in the nls_session_parameters table are ., (period comma)
-- the 1st represents the D(decimal) and the 2nd represents the G(grouping)

-- This reverses the settings to represent numbers the way they do in Europe
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = ',.';
-- This restores the settings to US standard
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';

-- language session parameters
ALTER SESSION SET NLS_LANGUAGE = 'AMERICAN';
-- Try the following with FRENCH, RUSSIAN, GERMAN, SPANISH, SWEDISH, GREEK, TURKISH
--    BULGARIAN, NORWEGIAN, FINNISH, ENGLISH, AMERICAN
-- Need UNICODE support: HEBREW, SIMPLIFIED CHINESE, ARABIC, HINDI, JAPANESE
SELECT to_char(SYSDATE, 'fmDay, DD Month rrrr' ),
        to_char(sysdate, 'DL') FROM dual;

-- Setting date format to something different
ALTER SESSION SET nls_date_format = "YYYY-MON-DD";
-- Resetting date format
ALTER SESSION SET nls_date_format = "DD-MON-RR";

/* -----------------------------------------------------------------------------
  Conversion functions - page 235-247
    TO_NUMBER(expr[, format_model[, nls_parms]])
------------------------------------------------------------------------------*/
-- Can't do math on strings
SELECT '3,654,422.34' - 1000000 FROM dual;


-- format model is on pp 238-239

  

SELECT * FROM nls_session_parameters;
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '@%';
SELECT to_number('3%654%422@34', '99G999G999D99'),
       to_number('3%654%422@34', '99G999G999D99') - 554422  FROM dual;

ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '*#';
SELECT to_number('3#654#422*34', '99G999G999D99') FROM dual;
SELECT to_number('3#654#422*34', '99G999G999D99') - 554422 FROM dual;

ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';
SELECT * FROM nls_session_parameters;

/* -----------------------------------------------------------------------------
  TO_CHAR(e1[, format_model[, nls_parms]])
    e1 can de character, numeric or date datatypes
------------------------------------------------------------------------------*/
SELECT sysdate, to_char(sysdate, 'YY'), to_char(sysdate, 'YYYY') FROM dual;


-- to_char with currency p240

-- other paramters may impact other strings like setting the language to French
-- may change the date output

/* -----------------------------------------------------------------------------
  TO_DATE(e1[, format_model[, nls_parms]])
    e1 is a character string
------------------------------------------------------------------------------*/
SELECT to_date('30-JUN-2015') FROM dual;



SELECT * FROM cruises;
INSERT INTO cruises VALUES (21, 1, 'Day at sea', null, null,
        to_date('15-JUN-80 06:30', 'DD-MON-RR HH24:MI'),
        to_date('15-JUN-80 18:30', 'DD-MON-RR HH24:MI'), 'DONE');
INSERT INTO cruises VALUES (22, 1, 'Day at sea', null, null,
        to_date('15-JUN-60 06:00', 'DD-MON-YY HH24:MI'),
        to_date('15-JUN-60 20:30', 'DD-MON-YY HH24:MI'), 'PLAN');


/* -----------------------------------------------------------------------------
  TO_TIMESTAMP, TO_DSINTERVAL, TO_YMINTERVAL - page 245-247
------------------------------------------------------------------------------*/
SELECT * FROM nls_session_parameters;
SELECT CURRENT_TIMESTAMP FROM dual;
                    
                    
/* -----------------------------------------------------------------------------
  Database Time and Session Time - page 247-250
------------------------------------------------------------------------------*/

-- Can't set database if any table uses TIMESTAMP WITH LOCAL TIME ZONE datatype
ALTER DATABASE SET TIME_ZONE = 'America/Los_Angeles';  -- using region name
ALTER DATABASE SET TIME_ZONE = 'UTC';                  -- using tz abbreviation
ALTER DATABASE SET TIME_ZONE = '-4:00';                -- using offset
-- Try to locate any tables using local time_zone
SELECT owner, table_name, column_name, data_type
  FROM dba_tab_columns  -- can also use all_tab_columns
  WHERE data_type LIKE '%LOCAL TIME_ZONE%'
  ORDER BY owner, table_name, column_name;

-- p251 using region names and abbreviations

  
-- Using time zone offset



/* -----------------------------------------------------------------------------
  new_time p 256
------------------------------------------------------------------------------*/

-- from_tz converts a TIMESTAMP to TIMESTAMP WITH TIME ZONE

-- to_timestamp_tz converts a date or string to a TIMESTAMP WITH TIME ZONE datatype

-- cast converts an expression to a specified datatype

/* -----------------------------------------------------------------------------
  EXTRACT(fm FROM timestamp) 
------------------------------------------------------------------------------*/
SELECT localtimestamp, extract(Minute FROM localtimestamp) FROM dual;

-- p260

-- 261

-- AT LOCAL

-- =============================================================================
-- Bonus material
-- =============================================================================
DROP TABLE book_contents;
CREATE TABLE book_contents (
  book_content_id  NUMBER(2,0) PRIMARY KEY,
  chapter_title    VARCHAR2(20),
  page_number      NUMBER(4,0)
);

INSERT INTO book_contents VALUES (1, 'My Story Begins', 1);
INSERT INTO book_contents VALUES (2, 'Early Years', 15);
INSERT INTO book_contents VALUES (3, 'Transformation', 39);
INSERT INTO book_contents VALUES (4, 'Finding Myself', 63);

SELECT * FROM BOOK_CONTENTS;
  
SELECT rpad (chapter_title || ' ',40,'.')  TableOfContents
  FROM book_contents ORDER BY book_content_id;
SELECT lpad(' ' || PAGE_NUMBER,40,'.') TableOfContents
  FROM book_contents ORDER BY book_content_id;

SELECT rpad('Chapter ' || book_content_id, 12) || 
       rpad(chapter_title || ' ' ,20,'.') ||
       lpad(' ' || page_number,30,'.') TOC
  FROM book_contents;

SELECT rpad (chapter_title || ' ',20,'.') || 
       lpad(' '  || PAGE_NUMBER,5,'*') TableOfContents
  FROM book_contents ORDER BY book_content_id;


SELECT to_number('3,654,422.34','999,999,999.99'),
       to_number('3,654,422.34','999,999,999.99')-1000000
FROM dual;

SELECT TO_CHAR(SYSDATE, 'DD-Month-RRRR HH:MI:SS AM') FROM dual;
SELECT to_char(orderdate,'DD MONTH, YYYY HH24:MI:SS') FROM orders;

