-- =============================================================================
-- Chapter 7 Reporting Aggregated Data using the Group Functions
-- =============================================================================
/* -----------------------------------------------------------------------------
  Aggregate Functions 
    Run on like rows.
    Process data FROM zero or more rows
    Return only one row's worth of data as their result
------------------------------------------------------------------------------*/
select * from books;

-- use cruises
SELECT * FROM ships;
INSERT INTO ships VALUES (9, 'Pacific Princess', 2446, 916, null, 80);
-- COUNT never counts null values

SELECT * FROM employees;
-- COUNT never returns a null value

-- use books
SELECT * FROM books;

-- Can't combine aggregate and non aggregate data

-- What is the longest book title?

/* -----------------------------------------------------------------------------
  GROUP BY clause
    Required when scalar and aggregate values are used in the SELECT list
------------------------------------------------------------------------------*/
-- shortcut using group by clause
SELECT * FROM books;
-- We can use the GROUP BY clause to look at aggregates and non-aggregates


-- switch to cruises schema
SELECT * FROM ship_cabins;
DESC ship_cabins;


-- We can group by multiple columns

-- GROUP BY does not have to be in the same order as the SELECT list
  

-- The WHERE clause, if used, must come before GROUP BY
-- WHERE restricts which rows the grouping is done on

-- Can't have a group function in the WHERE clause


SELECT * FROM ship_cabins;

-- you can nest an aggregate in another aggregate, but you are rolling
-- up data into a second level of aggregation

-- can only aggregate two deep p 295

-- SELECT list must always respect the level of aggregation and only include
-- expressions at the same level

/* -----------------------------------------------------------------------------
  HAVING clause
    Excludes specific GROUPS defined in the GROUP BY clause
    Must have a GROUP BY clause
    Can be either before or after GROUP BY
------------------------------------------------------------------------------*/
--  use books
-- what categories of books have an average cost > 30
-- where restricts individual rows, having restricts groups

-- having and group by can be reversed

-- To restrict the data itself, use a WHERE clause. WHERE happens before
-- anything else, then the functions are done and finally the results in the
-- having clause are displayed

-- Use cruises
  
  
/* -----------------------------------------------------------------------------
  RANK(c1,c2,c3) WITHIN GROUP (ORDER BY e1,e2,e3) - p283
    calculates the rank of a value within a group of values
    c1 datatype must match e1, c2 match e2, etc
------------------------------------------------------------------------------*/
-- use cruises
-- What row would be inserted with a value of 170 ordered by sq_ft

-- Where would a Presidential Suite of 852 sq ft be in the sort order?
  
/* -----------------------------------------------------------------------------
  FIRST, LAST - p 284
    syntax: aggr_function KEEP (DENSE_RANK [FIRST,LAST] ORDER BY expr1)
------------------------------------------------------------------------------*/
-- What is largest room for the smallest number of guests
SELECT * FROM ship_cabins ORDER BY guests, sq_ft DESC;

-- What is largest room for the largest number of guests
  
-- What is the largest 'Standard' room

-- =============================================================================
-- Bonus material
-- =============================================================================
SELECT * FROM ship_cabins;
SELECT room_style, room_type, min(sq_ft)
  FROM ship_cabins WHERE window != 'None'
  GROUP BY room_style, room_type;
  
SELECT room_style, room_type, min(sq_ft)
  FROM ship_cabins WHERE window != 'None'
  GROUP BY room_style, room_type
  HAVING room_type IN ('Standard', 'Large')
         OR min(sq_ft) > 1200
  ORDER BY 3;
  
-- Self Test Question 15
SELECT purpose, days, avg(project_cost) FROM projects
WHERE DAYS > 3
GROUP BY purpose, days
HAVING DAYS > 3;

--SELECT purpose, avg(project_cost) FROM projects
--GROUP BY purpose, DAYS > 3;

-- use books
-- Average retail by category displaying in '$XX.xx'
SELECT category, to_char(avg(retail), '$99.99') FROM books
  GROUP BY category;

-- What is the average profit for books by category 
SELECT category, to_char(avg(retail-cost), '$99.99') as "avg profit"
  FROM books GROUP BY category;

SELECT count(COUNT(title)) FROM books
GROUP BY category;

