-- =============================================================================
-- Chapter 4 Retrieving Data Using the SQL SELECT Statement
-- =============================================================================

/* -----------------------------------------------------------------------------
  Basic SELECT statements - page 138-122
    Mandatory SELECT clause    projection (limits columns)
    Mandatory FROM clause      lists the table from which to display the data
    Optional WHERE clause      selection (limits the rows)
    Optional ORDER BY clause   sorts the results
  Projection limits columns
------------------------------------------------------------------------------*/
-- use cruises
SELECT * FROM ships;

SELECT * FROM ports;

-- Exercise: Use projection to tell when the cruises are
SELECT * FROM cruises;

-- What kind of cabins are available
SELECT * FROM ship_cabins;

/* -----------------------------------------------------------------------------
  Selection limits rows
------------------------------------------------------------------------------*/
SELECT * FROM ships;

-- What ports can have 5 ships
SELECT * FROM ports;

-- Which cruises are sailing on August 17
SELECT * FROM cruises;


-- What suites are available for a family of 6?
SELECT * FROM ship_cabins;
                            
/* -----------------------------------------------------------------------------
  ORDER BY sorts output
------------------------------------------------------------------------------*/
SELECT * FROM ships;

-- We can use column numbers in the order by clause
-- The column number is the number of the column in the output

-- but not in the select clause

/* -----------------------------------------------------------------------------
  Pseudocolumns - p 143
------------------------------------------------------------------------------*/
  
-- rownum is the row number in the result set, not the original table

-- rownum is assigned before the order by clause is processed

/* -----------------------------------------------------------------------------
  DISTINCT and UNIQUE - pp 144-145
    Identifies a unique (no duplicates) set of values
    Both do exactly the same thing!
    Considered a clause of the SELECT statement
------------------------------------------------------------------------------*/
-- switch to books
SELECT * FROM customers;
SELECT * FROM customers ORDER BY state;

-- What states do I have customers in?

-- operates on the combination of state and city

/* -----------------------------------------------------------------------------
  Expressions - pp 146-148
------------------------------------------------------------------------------*/
SELECT * FROM books;
-- Use an expression in the select clause:
  
-- profit is an alias, once created can be used elsewhere in the select statement

-- ORDER BY can use an alias for sorting

-- ORDER BY can use an expression for sorting

-- Don't have to have retail-cost in the SELECT clause

/* -----------------------------------------------------------------------------
  Operators - p149
    Follows math precedence rules
------------------------------------------------------------------------------*/
SELECT 4+2 FROM customers;
SELECT 1/2 FROM dual;
SELECT 3+4*2+5 FROM dual;
SELECT 10+15*3 FROM dual;

-- can force precedence with parenthesis
SELECT (3+4) * (2+5) FROM dual;

-- Precedence at the same level is from left to right
SELECT (11-4 + (3+5) * .75 / 4) FROM dual;

CREATE test1 (
  one   NUMBER
);
DESC test1;

INSERT INTO test1 VALUES(100);

SELECT * FROM test1;
DROP TABLE test1;

/* -----------------------------------------------------------------------------
  Introduction to joins
    Joining is how we relate data from one part of the database to another
    Use multiple tables in a SELECT statement
------------------------------------------------------------------------------*/
-- use cruises
SELECT * FROM SHIPS;
SELECT * FROM PORTS;

-- What are the home ports for each ship?
  

-- Add Capacity to the SELECT clause
  
-- Capacity is ambiguous, so we have to specify which table to use

/* -----------------------------------------------------------------------------
  Introduction to views
    View is a window into one or more tables
    Like a table, but stores no data
    We use a query to define a view (CREATE AS syntax)
------------------------------------------------------------------------------*/

-- ============================================================================
-- BONUS MATERIAL
-- ============================================================================
-- use books
SELECT DISTINCT CATEGORY FROM books;

select unique category from books;

select isbn,title,retail
from books
order by retail;

SELECT DISTINCT lastname FROM customers;

select distinct lastname, firstname
from customers;

Select sysdate, customer# FROM customers;

SELECT 'Customer number =>', customer#, firstname, lastname 
  FROM customers WHERE state = 'FL';

SELECT sysdate, systimestamp FROM dual;

select 100/(5+3) from dual;

SELECT rownum, customer#, firstname, lastname, rowid
  FROM customers WHERE state = 'FL';

