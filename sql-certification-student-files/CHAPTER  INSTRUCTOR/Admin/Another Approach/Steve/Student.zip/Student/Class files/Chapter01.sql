-- =============================================================================
-- Chapter 1 Introduction to SQL
-- =============================================================================
-- Three types of comments in a sql worksheet

/* -----------------------------------------------------------------------------
  Getting our feet wet
------------------------------------------------------------------------------*/
-- Use books schema

-- 2nd select with just three columns

-- here is an example of a select from where statement

-- select lists the columns to be returned
-- from lists a table(s) from which to return columns
-- where tells us which rows from these tables are returned

-- all columns and all rows from table called books


-- count rows in orders table

-- return first and last names of all authors
-- return title,isbn,category from books;
-- return title, isbn, category for all books in category Fitness

/* -----------------------------------------------------------------------------
  Review Powerpoint Introduction To SQL
------------------------------------------------------------------------------*/
-- Creating database objects


-- create a new table myorder that has an order number, customer id
-- and shipstate
-- return name, order#, shipstate

-- deleting data

-- deleting database objects

-- ============================================================================
-- BONUS MATERIAL
-- ============================================================================
select * from dual;
select 4+3 from dual;
select 4+3 from customers;
select sysdate from dual;
select sessiontimezone from dual;
SELECT TZ_OFFSET(SESSIONTIMEZONE) FROM dual;

-- ============================================================================
-- EXERCISES
-- ============================================================================

-- 1. What is all the data we have on books in the booktore?
-- 2. What are the titles of the books in the bookstore?
-- 3. What are the customer's customer#, city and state?
-- 4. Who are the customers in New Jersey?
-- 5. What are the titles, cost and retail for family life books?
-- 6. What are all the orders shipped to Georgia?
