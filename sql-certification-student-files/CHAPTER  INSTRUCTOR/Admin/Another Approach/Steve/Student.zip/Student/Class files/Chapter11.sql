-- =============================================================================
-- Chpater 11 Managing Schema Objects
-- =============================================================================
/* -----------------------------------------------------------------------------
  ADD and MODIFY columns - pp 424-431
------------------------------------------------------------------------------*/
-- use cruises
SELECT * FROM cruise_orders;
DESC cruise_orders;
SELECT * FROM syn_constraints WHERE table_name = 'CRUISE_ORDERS';
DELETE FROM cruise_orders;

-- Adding a column

-- Adding multiple columns

-- Add a column to cruise_orders for order_date of type varchar2
-- To change a datatype we use MODIFY
-- to change the name of a column, use rename

-- can't really drop a not null constraint because its out of line syntax
-- To remove a not null constraint:

-- You can also modify multiple columns at once

DESC cruise_orders;
DROP TABLE cruise_orders;
CREATE TABLE cruise_orders (
  cruise_order_id      NUMBER CONSTRAINT pk_cruise_order_id PRIMARY KEY,
  order_date           DATE,
  posting_date         DATE,     
  cruise_customer_id   NUMBER,
  ship_id              NUMBER(7),
  CONSTRAINT fk_or_cu FOREIGN KEY (cruise_customer_id) REFERENCES cruise_customers(cruise_customer_id),
  CONSTRAINT fk_or_sh FOREIGN KEY (ship_id) REFERENCES ships(ship_id)
);

/* -----------------------------------------------------------------------------
  Modifying columns with data - page 428 - 430
    Table 11-1 p 429 lists permissible changes for ALTER TABLE MODIFY
------------------------------------------------------------------------------*/
SELECT * FROM cruise_orders;
-- set up the table for this exercise
-- When there is data in the table an the column is null or non existant
DESC cruise_orders;
SELECT * FROM syn_constraints WHERE table_name = 'CRUISE_ORDERS';

-- Set up the data for the exercise
INSERT INTO cruise_orders
  VALUES (1, '14-MAR-15', SYSDATE, 3, 1, 15, 'Yes');
INSERT INTO cruise_orders
  VALUES (2, '14-MAR-15', SYSDATE, 2, 1, 34, 'Yes');
INSERT INTO cruise_orders
  VALUES (3, '14-MAR-15', SYSDATE, null, 3, 47, 'No');
INSERT INTO cruise_orders (cruise_order_id, order_date, cruise_customer_id, ship_id)
  VALUES (4, '14-MAR-15', 1, 1);
INSERT INTO cruise_orders (cruise_order_id, order_date, cruise_customer_id, ship_id, travel_agency)
  VALUES (5, '31-MAR-15', 6, 4, 'Yes');
INSERT INTO cruise_orders (cruise_order_id, order_date, ship_id, weather_code, travel_agency)
  VALUES (6, sysdate, 5, 40, 'Who knows');
COMMIT;
SELECT * FROM cruise_orders ORDER BY cruise_order_id;
DESC cruise_orders;

-- NOT NULL
-- When column contains data in all rows
-- When column contains some data and some NULL values

-- can't make not null unless default specified
SELECT * FROM cruise_orders ORDER BY cruise_order_id;
DESC cruise_orders;
SELECT * FROM syn_constraints WHERE table_name = 'CRUISE_ORDERS';

-- UNIQUE constraint

-- FOREIGN KEY constraints
select * from cruise_customers;

-- CHECK constraints
-- if existing values don't violate constraint

SELECT * FROM cruise_orders ORDER BY cruise_order_id;
DESC cruise_orders;
SELECT * FROM syn_constraints WHERE table_name = 'CRUISE_ORDERS';

-- Automatic data conversion not supported

-- remove not null constraint

DESC cruise_orders;

/* -----------------------------------------------------------------------------
  DROP columns and UNUSED - pp 431-5
    Use UNUSED if the DROP would impact system performance 
------------------------------------------------------------------------------*/
SELECT * FROM cruise_orders;
-- Removing a column: drop syntax uses either DROP COLUMN or DROP ( )

-- quick way to make a column inaccessible

-- you can even add a new column with the same name
DESC cruise_orders;
SELECT * FROM cruise_orders;

-- to permanently remove it


/* -----------------------------------------------------------------------------
  Adding, changing and removing constraints - pp 436-453
    ALTER TABLE nn ADD CONSTRAINT - out of line syntax
    ALTER TABLE nn MODIFY CONSTRAINT - in line syntax
    ALTER TABLE nn DROP CONSTRAINT - removes a constraint
------------------------------------------------------------------------------*/
SELECT * FROM user_cons_columns;
SELECT * FROM user_constraints;
DROP TABLE mytest;
CREATE TABLE mytest(
  col_one   NUMBER
);

-- when we use out of line syntax, we must name the constraint
-- out of line syntax for dropping a constraint

-- Can't use out of line syntax for NOT NULL
-- in line syntax for adding a constraint
-- alternate way to drop a constraint without specifying name
-- only for unique and primary key constraints (p 440-441)

-- in line syntax for adding a constraint with a name
-- Can only use in line version to remove NOT NULL

SELECT * FROM syn_constraints WHERE table_name = 'MYTEST';

-- adding a column with a constraint

SELECT * FROM ucon WHERE table_name = 'MYTEST';
SELECT * FROM UIC WHERE table_name = 'MYTEST';
SELECT * FROM user_cons_columns WHERE table_name = 'MYTEST';

/* -----------------------------------------------------------------------------
  FOREIGN KEY constraints
------------------------------------------------------------------------------*/
DROP TABLE myparent;
CREATE TABLE myparent (
  one      NUMBER PRIMARY KEY,
  two      NUMBER UNIQUE
);

DROP TABLE mychild;
CREATE TABLE mychild (
  one      NUMBER PRIMARY KEY,
  two      NUMBER
);

-- only out of line syntax seems to work for foreign key (AFAIK)
-- Can't use in line syntax for FOREIGN KEY

INSERT INTO myparent VALUES (5, 1);
INSERT INTO myparent VALUES (10, 2);
INSERT INTO mychild VALUES (1, NULL);
INSERT INTO mychild VALUES (2, 10);
INSERT INTO mychild VALUES (3, 15); -- fails

SELECT * FROM myparent;
SELECT * FROM mychild;
SELECT * FROM syn_constraints WHERE table_name IN ('MYPARENT', 'MYCHILD');

-- Page 432
-- cannot drop a column if it is referenced by a FK in another table
-- unless you add the cascade constraints
-- can't drop parent because of foreign key reference
-- this occurs with or without data in the tables
DROP TABLE myparent;
-- Three ways to fix:

-- use cruises
SELECT table_name, constraint_name, constraint_type 
  FROM user_constraints WHERE r_constraint_name IN 
    (SELECT constraint_name FROM user_constraints
      WHERE table_name = 'PORTS' AND constraint_type = 'P');

-- page 450

/* -----------------------------------------------------------------------------
  Disabling and enabling constraints - pp 442-9
------------------------------------------------------------------------------*/
-- use cruises
SELECT * FROM ports;
SELECT * FROM ships;

-- port 14
-- deleting a row with no ship referencing it is ok

-- deleting a row with a ship refencing it

-- this temporarily turns off the constraint
-- try to reenable the constraint
-- this will reenable the constraint without checking the existing data
-- But new data is now checked, so this won't work

-- but we still should fix the data
select * from ports;
select * from ships;

/* -----------------------------------------------------------------------------
  DEFERRED - P 451
    We can also turn off a constraint temporarily with DEFERRED. The differece 
    between this and DISABLE is that when any commit occurs the constraints are 
    automatically turned back on and checked (constraints are set to IMMEDIATE)
------------------------------------------------------------------------------*/
-- page 451

SELECT constraint_name, DEFERRABLE FROM user_constraints
  WHERE table_name = 'SHIPS';

/* -----------------------------------------------------------------------------
  DELETE and ON DELETE - pp 450-1
------------------------------------------------------------------------------*/
INSERT INTO ships VALUES (13, 'SS Humorous', 940, 790, 7, 50);
-- this will now remove any ship referencing the port you are deleting
-- This will delete the port and set any ships home_port_id = 6 to null
select * from ports;
select * from ships;
COMMIT;

/* -----------------------------------------------------------------------------
  Function based indexes - pp 457 - 458
------------------------------------------------------------------------------*/
SELECT * FROM customers;
SELECT * FROM uix WHERE table_name = 'CUSTOMERS';

CREATE TABLE gas_tanks (
  gas_tank_id   NUMBER(7),
  tank_gallons  NUMBER(9),
  mileage       NUMBER(9)
);

/* -----------------------------------------------------------------------------
  Flashback operations - pp 457-8
    Following Error Message show in Oracle 11g standard edition
    ORA-00439: feature not enabled: Flashback Database
    Flashback database is disabled in standard edition or in standard one 
      edition. To be able to flashback on you have to use enterprise edition.
------------------------------------------------------------------------------*/
SELECT Parameter,VALUE FROM V$OPTION WHERE VALUE = 'FALSE';
ALTER DATABASE FLASHBACK ON;
ALTER SESSION SET RECYCLEBIN = ON;
CREATE TABLE houdini (
  voila VARCHAR2(30)
);
INSERT INTO houdini (voila) VALUES ('Now you see it.');
COMMIT;

DROP TABLE houdini;
FLASHBACK TABLE houdini TO BEFORE DROP;
SELECT * FROM houdini;
SELECT * FROM USER_RECYCLEBIN;

-- p 463
EXECUTE dbms_lock.sleep(15);
DELETE FROM houdini;
-- using timestamp
FLASHBACK TABLE houdini TO TIMESTAMP systemtimestamp -
                                      INTERVAL '0 00:00:30' DAY TO SECOND;
                                      
-- using system change numer
FLASHBACK TABLE houdini TO SCN scn_expression;
SELECT dbms_flashback.get_system_change_number FROM dual;
FLASHBACK TABLE houdini TO SCN timestamp_to_scn (systemtimestamp -
                                      interval '0 00:01:00' day to second);

-- p 468 using restore point
CREATE restore point balance_acct_01;
FLASHBACK TABLE houdini TO restore point balance_acct_01;

-- Conversion functions
SELECT timestamp_to_scn(systimestamp) now FROM dual;

/* -----------------------------------------------------------------------------
  External Tables - pp 468-72
    SQL*Loader and Data Pump are utilities you can use
    A DIRECTORY object is a location on the server filesystem
------------------------------------------------------------------------------*/
-- 1. First physically create the directory c:\temp

-- 2. Copy load_invoices.txt into C:\temp

-- 3. Then login as system and do:
CREATE OR REPLACE DIRECTORY bank_files AS 'C:\temp';
GRANT READ, WRITE ON DIRECTORY bank_files TO cruises;

-- 4. Login as cruises and create the external table
DROP TABLE invoices_external;
-- Can't use any comments inside this statement or the table won't load
-- make sure there are no extra lines that might be interpreted as null later when loading into PK
CREATE TABLE invoices_external (
  invoice_id     CHAR(6),
  invoice_date   CHAR(13),
  invoice_amt    CHAR(9),
  account_number CHAR(11)
) ORGANIZATION EXTERNAL (
  TYPE oracle_loader
  DEFAULT DIRECTORY bank_files
  ACCESS PARAMETERS(
    records delimited by newline
    skip 2
    fields (
      invoice_id     CHAR(6),
      invoice_date   CHAR(13),
      invoice_amt    CHAR(9),
      account_number CHAR(11)
    )
  )
  LOCATION ('load_invoices.txt')
);

DESC invoices_external;
SELECT * FROM invoices_external;
SELECT COUNT(*), SUM(invoice_amt) FROM invoices_external;

-- 5. Create a second table with correct datatypes
DROP TABLE invoices_revised;
CREATE TABLE invoices_revised (
  invoice_id     integer,
  invoice_date   date,
  invoice_amt    number,
  account_number varchar2(13)
);

-- 6. Insert into the new table
-- For a multirow insert, we do not have a VALUES clause,
-- column list is still optional if the columns are in the correct order

ALTER TABLE invoices_revised RENAME COLUMN account_number TO invoice_number;
SELECT * FROM invoices_revised 
  WHERE to_char(invoice_date, 'yyyy') = '2009';

-- =============================================================================
-- Bonus material
-- =============================================================================
-- use books schema
SELECT * FROM syn_constraints;
ALTER TABLE books ADD (status  VARCHAR2(25) DEFAULT 'Order');
-- p 430
ALTER TABLE books MODIFY retail_sale NOT NULL;  -- won't work because column has null in it.
-- can't make not null unless default specified
ALTER TABLE books ADD three VARCHAR2(5) DEFAULT 'yes' NOT NULL;
ALTER TABLE books MODIFY title NOT NULL;
ALTER TABLE books MODIFY (title VARCHAR2(50));
ALTER TABLE books MODIFY (title VARCHAR2(10));
DESC books;

ALTER TABLE books RENAME COLUMN retail_sale TO sale_price;
ALTER TABLE books MODIFY sale_price NUMBER (5,2);
ALTER TABLE books DROP COLUMN retail_sale;

select * from books;

alter table books add sale_price number;
UPDATE books SET sale_price = retail * .95;

savepoint unused_test;
-- quick way to make a column inaccessible
alter table books set unused column sale_price;
select * from user_unused_col_tabs;
select table_name, column_name, data_type, data_precision, data_scale
  from user_tab_columns where table_name = 'BOOKS';
rollback to unused_test; -- alter table commits before and after

-- you can even add a new column with the same name
alter table books add sale_price number(5,2) check (sale_price > 0);
desc books;

-- to permanently remove it
alter table books drop unused columns;

-- ============================================================================
-- EXERCISES
-- ============================================================================

