-- =============================================================================
-- Chapter 2 Using DDL Statements to Create and Manage Tables
-- =============================================================================
/* -----------------------------------------------------------------------------
  use SQL Developer to inspect the objects, schema - page 47-49
  CREATE TABLE syntax slide - page 51 rules for creating a table
------------------------------------------------------------------------------*/
-- use books
-- Create a simple table


-- must have at least one column

/* -----------------------------------------------------------------------------
  Naming, namspaces, structure - pp 52-9 
------------------------------------------------------------------------------*/
-- use books
-- at least one character but no more than 30

-- first character must be a letter

-- can include $,#,_ as well as numbers after the first character

-- Demonstrating case insensitivity

-- Using double quotes


/* -----------------------------------------------------------------------------
  Character data types - pp 61-62 
------------------------------------------------------------------------------*/
-- pp 61-62 character data types





/* -----------------------------------------------------------------------------
  Numeric data types - pp 62-63
------------------------------------------------------------------------------*/



/* -----------------------------------------------------------------------------
  Dates and timestamps - pp 63-64
------------------------------------------------------------------------------*/
CREATE TABLE testdates (
  id  integer,
  dt  DATE,                       -- date & time (d&t)
  ts  TIMESTAMP(2),               -- fractional seconds with no parameter, defaults to 6
  tz  TIMESTAMP WITH TIME ZONE,      -- d&t with tz
  ltz TIMESTAMP WITH LOCAL TIME ZONE -- d&t utc time (when queried gives local time)
);

-- log in as system  
-- displays how dates are actually stored in oracle:
-- nls: national language support

-- Page 63 (2/7)
-- date format in Oracle

/* -----------------------------------------------------------------------------
   pp Constraint types
     Not Null, Unique, Check, Default, Primary Key Foreign Key
   Four things to explore 
     1. in-line vs out-of line constraint creation
     2. naming vs not naming of constraints
     3. During vs after table creation
     4. Special rules for NOT NULL
-- ---------------------------------------------------------------------------*/
-- use books

-- Creating constraints during table creation
-- Inline constraint creation
-- constraint is declared on the same line as the column
-- in line creation of a primary key system named
-- in line creation of a primary key with our name

-- Out of line constraint creation
-- constraint creation happens at the end of the column list
-- CAN'T USE FOR NOT NULL CONSTARINT!!!
-- out of line creation of primary key system named 
-- out of line creation of primary key with our own name


/* -----------------------------------------------------------------------------
  NOT NULL constraint - pp 72-73
    NULL means 'I don't know', it is not 0 or not an empty string
    Cannot use out of line syntax for NOT NULL constraint
------------------------------------------------------------------------------*/
-- out of line with system name: FAILS
-- out of line with our own name: FAILS

-- cruises



SELECT * FROM ports1;

/* -----------------------------------------------------------------------------
  UNIQUE constraint - pp 74
------------------------------------------------------------------------------*/


-- UNIQUE can be done on multiple columns



/* -----------------------------------------------------------------------------
  Constraint creation after table creation - pp 69-70
    Primary Keys, inline vs out of line
    Creating constraints after table creation
      equivalent of inline constraint creation
      can be used for NOT NULL constraints
------------------------------------------------------------------------------*/
-- use cruises


-- The in line alter table version of constraint creation uses the keyword MODIFY

-- The out of line alter table constraint creation uses the keyword ADD
-- equivalent of out of line constraint creation format
-- out of line constraint creation can't be used for NOT NULL constraints


select * from ports2;

-- Removing a constraint
-- Constraint with a system generated name
-- Renaming a system generated constraint

-- multiple constraints pp 79,80
-- Constraint creation during table creating of multiple constraints

-- a composite primary key is made of more than one column
-- can only be done using out-of-line syntax


SELECT * FROM cruises2;

/* -----------------------------------------------------------------------------
  Check constraint - pp 79
    attaches an expression to a constraint
    must be the same datatype as the field it applies to
------------------------------------------------------------------------------*/

-- These statuses are case sensitive
-- Null values allowed for check constraint


/* -----------------------------------------------------------------------------
  Default
    Replaces omitted input with a predetermined value
    must be the same datatype as the field it applies to
------------------------------------------------------------------------------*/


/* -----------------------------------------------------------------------------
  Foreign key constraints
------------------------------------------------------------------------------*/
-- ports3 is the parent table that has the primary key

-- ships3 is the child with the foreign key that relates to the
-- pirmary key in the parent

-- Primary key exists:
-- Foreign key null:
-- Primary key does NOT exist: The foreign key enforces referential integrity
-- so you cannot create an orphan
-- One to many relationship of primary key:


select * from ships3;
select * from ports3;
-- Can't delete a record with a foreign key dependency
-- cascade doesn't work here
-- Can't create an orphan through deletion
-- Can delete records from ships 3 that don't have child records
-- In order to delete port_id=3 we must remove the dependency:
-- Now we can delete port 3:

-- Can't drop a table with foreign keys referencing it:
-- Can either drop ships3 first:
-- OR use cascade constraints:

-- We've dropped a lot of tables, so we need to purge the cache:
purge recyclebin;

-- ============================================================================
-- BONUS MATERIAL
-- ============================================================================
select sysdate from dual;
select sessiontimezone from dual;
SELECT TZ_OFFSET(SESSIONTIMEZONE) FROM dual;
ALTER SESSION SET TIME_ZONE = '-5:0';
select dbtimezone from dual;
select tz_offset(dbtimezone) from dual;
ALTER DATABASE SET TIME_ZONE = '-05:00';

-- ============================================================================
-- EXERCISES
-- ============================================================================
/* ---------------------------------------------------------------------------
1. Copy from page 59
2. Rename to cruises2
3. Create table
4. Check with desc
5. Check in SQL Developer for contraints
6. Drop table
7. Add named constraint
8. Create table
9. Look in IDE see named constraint
10 Drop table cruises2
-- ---------------------------------------------------------------------------
*/

/* -----------------------------------------------------------------------------
1. create table supplier2
2. supplier_id is the primary key can hold 10 digits
3. supplier_name can hold 50 letters and cannot be null
4. contact_name can hold 50 letters and can be null
5. Check work with insert statements
6. Drop table and constraints
NOTE: all constraints must be named by programmer
*/
/* -----------------------------------------------------------------------------
HOA C2 5. create table products4
a.) same fields as products
b.) no foreign key in create table
c.) use alter statement add: products_supplier_supplierid_fk
NOTE: use first supplier table with single field PK
*/
/* -----------------------------------------------------------------------------
HOA C2 6. create table products4
a.) same fields as products
b.) no foreign key in create table
c.) use alter statement add composite FK: prod_supp_suppid_suppname_fk
NOTE: use first supplier2 table with composite PK
*/
/* -----------------------------------------------------------------------------
HOA C2 7. You work for a company that has people who work out
of multiple locations. Create three small tables:
PEOPLE: a table about people
LOCATIONS: a table about locations
ASSIGNMENTS: a table about people at locations
*/
/*
HOA C2 8. create table people
-- ---------------------------------------------------
1.) pid is PK
2.) startdate is the startdate with default sysdate
3.) fname can hold 15 letters and cannot be null
4.) lname can hold 25 letters and cannot be null
5.) email can hold 25 letters must be unique
NOTE: all constraints must be named by programmer
*/
/*
HOA C2 9. create table assignments
-- ---------------------------------------------------
1.) pid (see #3 below)
2.) lid must have values (see below)
3.) create pk as (pid, lid)
4.) create fk to people
5.) create fk to locations
*/
/*
HOA C2 10. create table locations
-- ---------------------------------------------------
1.) lid is the primary key
2.) store name can hold 30 letters and cannot be null
4.) city can hold 30 letters and cannot be null
5.) state can hold 2 letters and cannot be null
*/
-- create a table for locations
/*
11. drop these three tables people, assignments, locations
*/
