-- =============================================================================
-- Chapter 10 Creating Other Schema Objects
-- =============================================================================
/* -----------------------------------------------------------------------------
  Views - pp 383-392
------------------------------------------------------------------------------*/
-- use cruises
SELECT * FROM ship_cabins;
SELECT * FROM ship_cabins WHERE window = 'Balcony'
  AND (sq_ft + balcony_sq_ft) BETWEEN 500 AND 1200;


SELECT * FROM cheap_rooms;
DESC cheap_rooms;
DROP VIEW cheap_rooms;

-- Adding column names for the resulting output
CREATE VIEW cheap_rooms AS
  -- fails because a column alias must be supplied:
  SELECT ship_id, room_number, room_type, (sq_ft + balcony_sq_ft)
    FROM ship_cabins WHERE window = 'Balcony'
    AND (sq_ft + balcony_sq_ft) BETWEEN 500 AND 1200;
    
-- modify to change the view
    
select * from employees;

SELECT first_name || ' ' || last_name, 
  (SELECT ship_name FROM ships WHERE ship_id = e.ship_id), primary_phone
  FROM employees e ORDER BY last_name, first_name;

-- We can name the view columns in the CREATE VIEW statement
SELECT * FROM vw_employees;
-- We can use views to modify existing data
-- We can add new data under certain conditions
SELECT * FROM employees;
SELECT * FROM vw_employees;
DESC employees;

-- inserting doesn't work because of a not null constraint not being met
-- updating and deleting will work because we don't need to consider constraints
-- rules for updateable views on p 388


-- modifying doesn't work because columns don't exist
-- This works because we are updating a real column

/* -----------------------------------------------------------------------------
  building a view depending on multiple tables - p 385
------------------------------------------------------------------------------*/
SELECT ship_id, min(salary) min_salary
  FROM employees JOIN pay_history USING (employee_id)
  WHERE end_date IS NULL
  GROUP BY ship_id;



-- These don't work at all because of the GROUP BY and JOIN


-- These don't work at all because of the JOIN
--DELETE FROM emp_trend WHERE ship_id = 1; investigate
SELECT * FROM employees;
SELECT * FROM pay_history;
SELECT * FROM emp_trend;

/* -----------------------------------------------------------------------------
  Inline views p 389
    A view that is a subquery is the FROM clause of SELECT statement
------------------------------------------------------------------------------*/
SELECT * FROM (SELECT * FROM (SELECT * FROM ships));

-- This statement from ch 9 uses two inline views

-- alter view covered in chapter 14

/* -----------------------------------------------------------------------------
  Sequences - pp 392-397
------------------------------------------------------------------------------*/
-- this will fail if nextval hasn't been used yet IN A SESSION

-- START WITH is first number used in the sequence
-- If START WITH ommitted, defaults to MINVALUE
-- INCREMENT BY specifies how it counts
-- If ommitted, defaults to 1
-- MAXVALUE specifies the maximum number used in the sequence
-- If ommitted, there is no limit (NOMAXVALUE)
-- MINVALUE specifies the minimum number used in the sequence
-- If ommitted, defaults to 1 (NOMINVALUE)
-- Putting it all together
-- START WITH must be >= MINVALUE:
-- CYCLE causes the generator to restart at MINVALUE
-- If ommitted, defaults to NOCYCLE
-- INCREMENT BY negative numbers counts down, recycles to MAXVALUE

-- NOCYCLE, NOMINVALUE, NOMAXVALUE are the defualts


-- Rules for using sequences on p 396

SELECT * FROM work_history;

/* -----------------------------------------------------------------------------
  Indexes - pp 397-404
------------------------------------------------------------------------------*/
-- Information on an index
SELECT * FROM user_indexes WHERE table_name = 'CRUISES';
-- Information on which table columns have an index
SELECT * FROM user_ind_columns WHERE table_name = 'CRUISES';

CREATE TABLE seminars (
  seminar_id   NUMBER  PRIMARY KEY,
  seminar_name VARCHAR2(30) UNIQUE
  seminar_start DATE DEFAULT SYSDATE
);

-- Implicit index creation
-- Indexes are automatically created on unique fields

DROP TABLE seminars;  
-- Explicit index creation
-- syntax described in ch 11 p 455

-- After table creation:
-- can't create an index on a column that already has one

-- composite indexes are on multiple columns


-- p 404 If you drop a table on which an index is based, the index
--       is automatically dropped
drop table seminars;

-- Explicitly dropping an index:

/* -----------------------------------------------------------------------------
  Synonyms - pp 404-410
------------------------------------------------------------------------------*/
-- use cruises
SELECT * FROM employees;
-- private sysnonyms are stored in the data dictionary in user_synonyms
SELECT * FROM user_synonyms;
-- Public synonyms are stored in dba_synonyms (log in as system)
SELECT * FROM dba_synonyms WHERE table_owner = 'CRUISES';
SELECT * FROM dba_synonyms WHERE synonym_name = 'EM';

-- switch to books
-- this works because we granted all privileges to both books and cruises
-- just preceed the object name with the schema name
-- We don't need the schema name for public synonym

-- run this from cruises

-- We can use the OR REPLACE syntax for synonyms

-- private and public synonyms are in different namespaces

-- private synonyms have prioirty over public synonyms

-- either schema

-- use cruises schema

-- use books schema
-- ============================================================================
-- BONUS MATERIAL
-- ============================================================================
-- use books
SELECT * FROM customers;
CREATE VIEW vw_customers
  AS SELECT customer#,lastname,firstname,state,zip
  FROM customers;
DESC customers; 
DESC vw_customers; 

-- ============================================================================
-- EXERCISES
-- ============================================================================

