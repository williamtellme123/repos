-- =============================================================================
-- Chpater 15 Manipulating Large Data Sets
-- setup from Chapter 14 stuff
-- =============================================================================
/* -----------------------------------------------------------------------------
  Manipulate Data Using Subqueries - pp 560-3 
    CTAS (Create Table As Select)
------------------------------------------------------------------------------*/
-- use books

SELECT * FROM books2;


SELECT * FROM customers2;


select * from customers;
select * from customers2;

-- add constraints
INSERT INTO customers2 (fullname, code) VALUES ('Bill Shakespear', '3H4J5');
INSERT INTO customers2 (fullname, code) VALUES ('Johnny Milton', '3H4J5');

SELECT * FROM customers2;

-- page 562
-- switch to cruises
select * from ship_cabins;

-- STUDENT EXERCISE: Type in the code from page 562:

SELECT * FROM room_summary;

-- INSERT using a subquery:

-- UPDATE using correlated subqueries

-- Code from page 566:
-- normal update uses column = 'new data', 
-- Test subquery:
-- Replace null values with 0

/* -----------------------------------------------------------------------------
  Multitable inserts - pp 571-582
------------------------------------------------------------------------------*/
-- preparation
-- log in as cruises
-- Go back to chapter 11, check EXTERNAL TABLE table from c:\tempinvoices.txt
-- exists and convert into invoices_revised with correct data types
SELECT count(*) FROM invoices_revised;
SELECT * FROM invoices_revised;
-- Data in the table is from 2009 to 2011
SELECT COUNT(*) as other FROM invoices_revised
WHERE invoice_date <  to_date('01/01/09','mm/dd/yy')
  OR invoice_date > to_date('12/31/11','mm/dd/yy');


-- CASE WHEN syntax from chapter 6
  
DESC invoices_revised;

CREATE TABLE invoices_2009 (
  INVOICE_ID          NUMBER(38),
  INVOICE_DATE        DATE,   
  INVOICE_AMT         NUMBER,
  INVOICE_NUMBER      VARCHAR2(13)
);

CREATE TABLE invoices_2010 (
  INVOICE_ID          NUMBER(38),
  INVOICE_DATE        DATE,   
  INVOICE_AMT         NUMBER,
  INVOICE_NUMBER      VARCHAR2(13)
);

CREATE TABLE invoices_2011 (
  INVOICE_ID          NUMBER(38),
  INVOICE_DATE        DATE,   
  INVOICE_AMT         NUMBER,
  INVOICE_NUMBER      VARCHAR2(13)
);

CREATE TABLE invoices_all (
  INVOICE_ID          NUMBER(38),
  INVOICE_DATE        DATE,   
  INVOICE_AMT         NUMBER,
  INVOICE_NUMBER      VARCHAR2(13)
);

SELECT * FROM user_tables WHERE table_name LIKE 'INV%';

/* -----------------------------------------------------------------------------
  Unconditional multitable insert - p 572
    copies one table into 4 tables
    No WHEN clauses
    Requires ALL keyword
------------------------------------------------------------------------------*/

-- Clean up because we really want to do something else

-- test statements used for checking results of inserts below
SELECT count(*) as total,
       COUNT(CASE WHEN to_char(invoice_date, 'RRRR') < '2010' THEN 1 END) AS Y09,
       COUNT(CASE WHEN to_char(invoice_date, 'RRRR') = '2010' THEN 1 END) AS Y10,
       COUNT(CASE WHEN to_char(invoice_date, 'RRRR') > '2010' THEN 1 END) AS Y11
  FROM invoices_all;

SELECT
  (SELECT count(*) FROM invoices_revised) AS original,
  (SELECT count(*) FROM invoices_2009) AS y2009,
  (SELECT count(*) FROM invoices_2010) AS y2010,
  (SELECT count(*) FROM invoices_2011) AS y2011,
  (SELECT count(*) FROM invoices_all) AS archived
FROM dual;

/* -----------------------------------------------------------------------------
  Conditional multitable insert with 'ALL' from p 577
    WHEN expr1 THEN 
    ALL is optional and the default
------------------------------------------------------------------------------*/
-- runs in about 120-150 msec

TRUNCATE TABLE invoices_2009;
TRUNCATE TABLE invoices_2010;
TRUNCATE TABLE invoices_2011;
TRUNCATE TABLE invoices_all;

/* -----------------------------------------------------------------------------
  Conditional multitable insert with 'FIRST' from p 577
    Process the first WHEN condition, then goes on to next record 
    ELSE is optional and must be last if included
------------------------------------------------------------------------------*/
-- runs in about 100-120 msec
  
-- extreemly verbose version
INSERT FIRST
    WHEN (to_char(invoice_date, 'RRRR') = '2009') THEN
        INTO invoices_2009 (invoice_id, invoice_date, invoice_amt, invoice_number)
        VALUES (invoice_id, invoice_date, invoice_amt, invoice_number)
        INTO invoices_archived (invoice_id, invoice_date, invoice_amt, invoice_number)
        VALUES (invoice_id, invoice_date, invoice_amt, invoice_number)
    WHEN (to_char(invoice_date, 'RRRR') = '2010') THEN
        INTO invoices_2010 (invoice_id, invoice_date, invoice_amt, invoice_number)
        VALUES (invoice_id, invoice_date, invoice_amt, invoice_number)
    INTO invoices_all (invoice_id, invoice_date, invoice_amt, invoice_number)
        VALUES (invoice_id, invoice_date, invoice_amt, invoice_number)
    WHEN (to_char(invoice_date, 'RRRR') = '2011') THEN
        INTO invoices_2011 (invoice_id, invoice_date, invoice_amt, invoice_number)
        VALUES (invoice_id, invoice_date, invoice_amt, invoice_number)
    INTO invoices_all (invoice_id, invoice_date, invoice_amt, invoice_number)
        VALUES (invoice_id, invoice_date, invoice_amt, invoice_number)
SELECT invoice_id, invoice_date, invoice_amt, account_number 
    FROM invoices_revised; 
   

-- conditional insert that is not multitable
-- p 578 (initial query doesn't work)
-- target table:
SELECT * FROM salary_chart;
-- source table:
SELECT * FROM positions;

SELECT a.position AS employee, a.max_salary AS employee_salary,
       b.position AS boss, b.max_salary AS boss_salary
  FROM positions a JOIN positions b ON a.reports_to = b.position_id;


/* -----------------------------------------------------------------------------
  Pivot table - pp 580-2
    Use conditional multitable insert statment to transform data from a
    structure into rows and columns structure
------------------------------------------------------------------------------*/
SELECT * FROM ship_cabin_statistics; -- target table
SELECT * FROM ship_cabin_grid;       -- source table




/* -----------------------------------------------------------------------------
  Merge Rows in a Table - pp 582-6
   combines insert, update and delete into a single SQL statement
------------------------------------------------------------------------------*/
SELECT * FROM wwa_invoices;    -- target
SELECT * FROM ontario_orders;  -- source

SELECT * FROM wwa_invoices;
SELECT * FROM ontario_orders;
-- add a row to test deletion
INSERT INTO wwa_invoices VALUES (30, 'WWA-001', '20-AUG-09', 'test');

--p 586 add delete

select * from wwa_invoices;

/* -----------------------------------------------------------------------------
  Flashback Queries - pp 589-600
------------------------------------------------------------------------------*/
-- setup the table for testing
DROP TABLE chat;
CREATE TABLE chat (
  chat_id     NUMBER(11) PRIMARY KEY,
  chat_user   VARCHAR2(10),
  yacking     VARCHAR2(40)
);
CREATE SEQUENCE seq_chat_id;
drop sequence seq_chat_id;
-- populate the table
INSERT INTO chat VALUES (seq_chat_id.nextval, user, 'Hi there.');
INSERT INTO chat VALUES (seq_chat_id.nextval, user, 'Welcome to our chat room.');
INSERT INTO chat VALUES (seq_chat_id.nextval, user, 'Online order form is up.');
INSERT INTO chat VALUES (seq_chat_id.nextval, user, 'Over and out.');
COMMIT;

-- page 589
-- page 590
-- wait for 2 minutes; rows are in there
SELECT * FROM chat;

-- after running first time, run this then the select again
DELETE FROM chat;
COMMIT;

-- page 590
-- See older data
--Keep doing this until it shows up empty (1.5 minutes)
-- page 591
-- log in as system 

-- add the data back into the table
-- wait for a couple minutes

-- flashback versions query
-- have to do commits to see the changes
-- page 594
-- FLASHBACK VERSIONS QUERY

--page 596
-- OTHER PSUEDO COLUMNS
SELECT chat_id, versions_startscn, versions_endscn, versions_operation
  FROM chat versions BETWEEN TIMESTAMP minvalue AND maxvalue AS OF TIMESTAMP systimestamp - interval '0 00:1:30' DAY TO second
  ORDER BY chat_id,versions_operation DESC;

-- page 598 middle
-- FLASHBACK TRANSACTION QUERY


-- =============================================================================
-- Bonus material
-- =============================================================================
SELECT COUNT(*) as "2009" FROM invoices_revised
  WHERE invoice_date >= to_date('01/01/09','mm/dd/yy')
    AND invoice_date <= to_date('12/31/09','mm/dd/yy');

SELECT invoice_id,invoice_date,invoice_amt,invoice_number
FROM invoices_revised
  WHERE invoice_date > (add_months(SYSDATE, -60));

SELECT count(*) tot_count,
       count(CASE WHEN invoice_date >= to_date('01/01/09', 'MM/DD/YY')
                   AND invoice_date <= to_date('12/31/09', 'MM/DD/YY')
                   then 1 end) as "2009",
       count(CASE WHEN invoice_date >= to_date('01/01/10', 'MM/DD/YY')
                   AND invoice_date <= to_date('12/31/10', 'MM/DD/YY')
                   THEN 1 END) AS "2010",
       count(CASE WHEN invoice_date >= to_date('01/01/11', 'MM/DD/YY')
                   AND invoice_date <= to_date('12/31/11', 'MM/DD/YY')
                   THEN 1 END) AS "2011"
  FROM invoices_revised;

SELECT sum(invoice_amt) grand_total,
       sum(CASE WHEN to_char(invoice_date, 'RRRR') < '2010' THEN invoice_amt END) AS TOT09,
       sum(CASE WHEN to_char(invoice_date, 'RRRR') = '2010' THEN invoice_amt END) AS TOT10,
       sum(CASE WHEN to_char(invoice_date, 'RRRR') >= '2011' THEN invoice_amt END) AS TOT11
  FROM invoices_revised;

SELECT * FROM PORTS versions BETWEEN TIMESTAMP minvalue AND maxvalue;
SELECT * FROM PORTS AS OF TIMESTAMP systimestamp - interval '0 0:01:30' DAY TO SECOND;

-- for pivot table if necessary
CREATE TABLE ship_cabin_grid (
    room_type VARCHAR2(20) ,
    ocean     NUMBER ,
    balcony   NUMBER ,
    no_window NUMBER
);

BEGIN
  INSERT INTO ship_cabin_grid VALUES('ROYAL', 1745,1635, NULL);
  INSERT INTO ship_cabin_grid VALUES('SKYLOFT', 722,72235, NULL);
  INSERT INTO ship_cabin_grid VALUES('PRESIDENTIAL', 1142,1142, 1142);
  INSERT INTO ship_cabin_grid VALUES('LARGE', 225,NULL, 211);
  INSERT INTO ship_cabin_grid VALUES('STANDARD', 217,554, 586);
END;
/

