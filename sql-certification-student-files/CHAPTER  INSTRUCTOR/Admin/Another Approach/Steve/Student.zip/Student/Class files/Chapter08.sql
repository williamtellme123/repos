-- =============================================================================
-- Chapter 8 Displaying Data from Multiple Tables
-- =============================================================================

/* -----------------------------------------------------------------------------
  Types of joins: 
    INNER JOIN: connects rows in two or more tables if and only if there are matched 
          rows in all the tables being joined 
    OUTER JOIN: includes data that has no matching values come in three flavors:
      FULL JOIN returns all matches, plus unmatched data from both tables
      LEFT JOIN returns all matches, plus unmatched data from the table on the 
          left of the JOIN
      RIGHT JOIN returns all matches, plus unmatched data from the table on the 
          right of the JOIN
------------------------------------------------------------------------------*/
-- use cruises
SELECT * FROM ships;
SELECT * FROM ports;

-- INNER JOIN
-- Keyword INNER is optional
  
-- OUTER JOIN
-- FULL joins return all matches, plus all ships and ports with no matches
-- OUTER is optional

-- Outer joins
-- LEFT joins return all matches, plus all ships without a home_port

-- RIGHT joins return all matches, plus all ports listed without a ship

-- OUTER is optional for all OUTER joins

/* -----------------------------------------------------------------------------
  JOIN syntaxes:
    JOIN ON: more flexible can be used with tables that have different column
             names in the JOIN
    JOIN USING: requires column names to be identical
    old style syntax: doesn't use the JOIN keyword at all, but uses the WHERE
             clause to do the joining
------------------------------------------------------------------------------*/
-- use books
SELECT * FROM customers;
SELECT * FROM orders;
DESC orders;

-- INNER JOIN
  
-- FULL OUTER JOIN
-- We can't do a full outer join using the old style syntax
SELECT customers.customer#, firstname, lastname, order#, orderdate
  FROM customers, orders
  WHERE customers.customer#(+) = orders.customer#(+); -- fails here
  
-- LEFT OUTER JOIN

-- RIGHT OUTER JOIN
  
/* -----------------------------------------------------------------------------
  Table alias is alternate name for a table
    Defined in the FROM clause
    Replace the table prefix in the SELECT, WHERE, ORDER BY clauses
------------------------------------------------------------------------------*/
SELECT * FROM customers;
SELECT * FROM orders;

-- Replace customer with 'c' and orders with 'o'
  
-- Don't need table aliases in JOIN USING, but can still use them
-- Can't use table aliases in the USING clause

-- Old style using table aliases

/* -----------------------------------------------------------------------------
  NATURAL JOIN: Lets SQL identify which columns to use for joining.
    Requires that columns used for joining have the same name
    Are INNER JOINS
------------------------------------------------------------------------------*/



/* -----------------------------------------------------------------------------
  Multitable joins
------------------------------------------------------------------------------*/
SELECT * FROM books;
SELECT * FROM orders;
SELECT * FROM orderitems;
SELECT * FROM customers;

-- Using JOIN ON syntax
  
-- Using JOIN USING (column names must be identical)
-- We don't need table aliases

-- a join using an older style of syntax (using the where clause)

-- You can mix the syntaxes

-- EXERCISE: provide a sum for each order#
-- start out relating the four tables

-- relate the book retail values and quantities to the orders

-- get the total cost for each line item

-- aggregate the line items

  -- multitable joins 325 bottom
  -- page 325 bottom alternate
  -- no
  -- page 325 bottom alternate
  -- yes
  
/* -----------------------------------------------------------------------------
  Non equi-joins p 326-328
    Can't use USING or NATURAL JOINS
------------------------------------------------------------------------------*/
select * from promotion;
select * from books;


-- old style syntax

/* -----------------------------------------------------------------------------
  Self joins p 328-330
    can't use USING because the column names are different
------------------------------------------------------------------------------*/
SELECT * FROM customers;

-- Which customers referred whom?
  
-- use cruises
SELECT * FROM positions;
-- Who reports to whom?


/* -----------------------------------------------------------------------------
  Cartesian product 
    the product of the rows and sum of the columns
    There is no JOIN criteria
    Also known as a CROSS JOIN
------------------------------------------------------------------------------*/
-- use books
DELETE FROM customers WHERE customer# >= 5000;

-- determine the number of columns and rows in a cartesian
-- product between 2 tables customers and orders;
select * from customers;  -- 20 records, 8 columns
select * from orders;     -- 21 records, 8 columns

SELECT * FROM customers, orders; -- 420, 16 columns
SELECT count(*) FROM customers, orders;

-- determine the number of columns and rows in a cartesian
-- product between 3 tables customers, orders and orderitems;
SELECT * FROM orderitems;  -- 32 rows, 4 columns
SELECT count(*) FROM customers CROSS JOIN orders CROSS JOIN orderitems;
SELECT * FROM customers, orders, orderitems; -- 13440 rows, 20 columns
  
-- determine the number of columns and rows in a cartesian
-- product between 4 tables customers and orders and orderitems and books;
-- A cartesian produces a sum of all the columns and product of all the rows
SELECT * FROM books;  -- 14 rows, 8 columns
SELECT count(*) FROM customers, orders, orderitems, books; 
SELECT * FROM customers, orders, orderitems, books;  -- 188160 rows, 28 columns

-- Projection limits columns
SELECT firstname, lastname, o.order#, orderdate, b.isbn, title, category
  FROM customers, orders o, orderitems, books b;  -- 188160 rows, 7 columns

-- Selection limits rows
SELECT count(*) 
  FROM customers c, orders o, orderitems oi, books b
  WHERE c.customer# = o.customer#;

SELECT firstname, lastname, o.order#, orderdate, b.isbn, title, category
  FROM customers c, orders o, orderitems oi, books b
  WHERE c.customer# = o.customer#;  -- 9408 rows, 7 columns

SELECT count(*) 
  FROM customers c, orders o, orderitems oi, books b
  WHERE c.customer# = o.customer# AND o.order# = oi.order#;

SELECT firstname, lastname, o.order#, orderdate, b.isbn, title, category
  FROM customers c, orders o, orderitems oi, books b
  WHERE c.customer# = o.customer# AND o.order# = oi.order#;  -- 448 rows, 7 columns

SELECT count(*) 
  FROM customers c, orders o, orderitems oi, books b
  WHERE c.customer# = o.customer# AND o.order# = oi.order# AND oi.isbn = b.isbn;

SELECT firstname, lastname, o.order#, orderdate, b.isbn, title, category
  FROM customers c, orders o, orderitems oi, books b
  WHERE c.customer# = o.customer# AND o.order# = oi.order# AND oi.isbn = b.isbn;  -- 32 rows, 7 columns

-- =============================================================================
-- Bonus material
-- =============================================================================

-- page 319 bottom
SELECT ship_id, ship_name, port_name
  FROM ships JOIN ports ON home_port_id = port_id(+)
  ORDER BY ship_id;

-- page 323 top
SELECT e.employee_id, last_name, street_address
  FROM employees e INNER JOIN addresses a
  ON e.employee_id = a.employee_id;

-- page 324 bottom
SELECT employee_id, last_name, street_address
  FROM employees LEFT JOIN addresses USING (employee_id);

-- use cruises
SELECT S.SCORE_ID, S.TEST_SCORE, G.GRADE
  FROM SCORES S JOIN GRADING G
    ON S.TEST_SCORE BETWEEN G.SCORE_MIN AND G.SCORE_MAX
    ORDER BY 1;
    
INSERT INTO SCORES (SCORE_ID, TEST_SCORE)
    VALUES (8, 68);

  
SELECT P.PORT_NAME, S.SHIP_NAME, SC.ROOM_NUMBER
    FROM PORTS P JOIN SHIPS S ON P.PORT_ID = S.HOME_PORT_ID
                 JOIN SHIP_CABINS SC USING (SHIP_ID);
               
SELECT FIRST_NAME, LAST_NAME, STREET_ADDRESS  
  FROM EMPLOYEES NATURAL JOIN ADDRESSES;

-- =============================================================================
-- STUDENT EXERCISES
-- =============================================================================
-- EXERCISE: what authors does Bonita Morales like?
-- bookauthor & author
SELECT * FROM author;


-- Find out what authors a customer likes

-- how many books in each category were ordered by each customer in Florida

-- return a count of authors with each title
  
-- return a count of books each author wrote

-- use cruises
-- What ships are home ported in Charleston?
    
-- 1. List employee's ID and first and last names, address, city, state,
-- zip with JOIN ON syntax
-- Use table aliases for all returned columns where possible
                    
-- 2. Repeat question 1 with the keyword "USING"
--Use table aliases for all returned columns where possible

-- 3. List cruise name and captains ID, captains name address, city, state,zip 
--    with JOIN ON syntax
  
-- 4. Repeat question 3 using keyword "USING" where possible
  
-- 6. Return Cruise name, cruise ID, the captains employee ID,
-- and captains first and last names, street, city, state, zip.
-- use the join on technique;
  
-- 7. Return captains name, city, state, and start date, along with ship_name,
-- cruise_name, and port_name

-- 8 For the port of Baltimore return
  --Total cost of all projects (shown with dollars and commas)
  --Avg cost per project (shown with dollars and commas)
  --Toal number of projects
  --Total number of man_hours (assume a crew of 5 people 8 hours per day)
