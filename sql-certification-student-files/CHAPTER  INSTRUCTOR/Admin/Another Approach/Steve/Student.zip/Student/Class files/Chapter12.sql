-- =============================================================================
-- Chapter 12 Using the Set Operators
-- =============================================================================
/* -----------------------------------------------------------------------------
  Set operators combine two or more SELECT statements to merge their output
    table p 488  (draw Venn diagram)
    The four set operators are UNION, UNION ALL, INTERSECT and MINUS
    Output takes its column headings from the first SELECT statement
------------------------------------------------------------------------------*/
-- use cruises
SELECT * FROM contact_emails;
SELECT * FROM online_subscribers;

SELECT contact_email_id, email_address FROM contact_emails;
SELECT online_subscriber_id, email FROM online_subscribers;

/* -----------------------------------------------------------------------------
  UNION - pp 490-494
    Combines two row sets eliminating duplicates
------------------------------------------------------------------------------*/


/* -----------------------------------------------------------------------------
  UNION ALL - p 494
    Combines two row sets including duplicates
------------------------------------------------------------------------------*/

/* -----------------------------------------------------------------------------
  INTERSECT - pp 494-5
    Includes only row sets that are in both queries
------------------------------------------------------------------------------*/

/* -----------------------------------------------------------------------------
  MINUS - pp 495-6
    Subtracts the rows in the second row set from the first row set
    Order matters
------------------------------------------------------------------------------*/


/* -----------------------------------------------------------------------------
  Datatype similarity - p
------------------------------------------------------------------------------*/
SELECT capacity, home_port_id FROM ships
  UNION
SELECT capacity, port_id FROM ports;

-- Wont work if data types are dissimilar
--------------------------------------------------------------------------------

--STUDENT EXERCISE:
select * from store_inventory;
select * from furnishings;

-- What items are in the store inventory that are not in furnishings?

-- What items are found in both

/* -----------------------------------------------------------------------------
  Combinations - p496
    All set operators have the same level of precedence
    Precedence forced by parenthesis
------------------------------------------------------------------------------*/
-- Precedence forced by parenthesis


/* -----------------------------------------------------------------------------
  Control the order of rows returned - pp 497-499
------------------------------------------------------------------------------*/
SELECT * FROM cruise_customers;
SELECT * FROM employees;


-- ORDER BY can't be anywhere except the last clause

-- can't use email because its in the second select

-- =============================================================================
-- Bonus material
-- =============================================================================
-- Question 8
SELECT product FROM store_inventory
UNION ALL
SELECT item_name FROM furnishings
MINUS  (
        SELECT product FROM store_inventory WHERE product = 'Towel'
         UNION
        SELECT item_name FROM furnishings WHERE item_name = 'Towel'   );


-- question 12
select * from store_inventory;
select a.sub_date, count(*)
from online_subscribers a join
        ( select to_date(last_order,'yyyy/mm/dd') last_order, product 
           from store_inventory
            UNION
          select added, item_name from furnishings
         ) b
    on a.sub_date = b.last_order
group by a.sub_date;

-- =============================================================================
-- EXERCISES
-- =============================================================================
