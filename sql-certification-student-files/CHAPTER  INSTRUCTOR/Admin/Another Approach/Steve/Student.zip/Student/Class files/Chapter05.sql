-- =============================================================================
-- Chapter 5 Restricting and Sorting Data
-- =============================================================================
/* -----------------------------------------------------------------------------
  Limit rows using the WHERE clause - p 170
------------------------------------------------------------------------------*/
-- use cruises
SELECT * FROM ship_cabins;
    
-- three ways to say not equal (p172-173)


-- Comparison can be used with strings
-- Uses the ASCII table, character by character comparisons
-- All lowercase letters are > uppercase letters

-- Comparisons with dates
SELECT * FROM cruises;
-- Later dates are greater dates
-- Does not use ASCII table


/* -----------------------------------------------------------------------------
  LIKE operator - p 174
------------------------------------------------------------------------------*/
SELECT * FROM ship_cabins;

SELECT * FROM ports;

-- p 176

-- wildcard string must be after the LIKE keyword

/* -----------------------------------------------------------------------------
  AND, OR, NOT - p 177
------------------------------------------------------------------------------*/
-- use cruises
SELECT * FROM work_history;
INSERT INTO work_history VALUES (9, 2, '23-JUN-01', '21-MAY-04', 3, 'Closed');
COMMIT;

-- Boolean Operator Precedence:
-- NOT is first
-- Can use paranthesis to force precendence
-- AND will be evaluated first here:
-- AND is evaluated before OR regardless of which comes first

-- To force OR first, use parenthesis
    
/* -----------------------------------------------------------------------------
  IN operator - p 181-182
------------------------------------------------------------------------------*/
-- use books
SELECT * FROM customers;  -- 24 records
-- for OR at least one expression needs to be true to return a result

-- A lot easier to do using the IN operator
  
 
-- Cannot use wildcards in IN 
-- syntactically correct, but evaluates % or _ as literal

-- use cruises
SELECT port_name FROM ports
  WHERE country IN ('UK','USA','Bahamas');
  
/* -----------------------------------------------------------------------------
  BETWEEN operator - p 182
------------------------------------------------------------------------------*/
-- use cruises
SELECT * FROM ports;

-- All these statements are equivalent AND inclusive (includes values of 3 and 5)

-- BETWEEN also works with NOT

-- Exclusive command

-- Must have minimum value first:

-- BETWEEN used with strings
-- BETWEEN can use wildcards

-- BETWEEN can be used with dates
SELECT * FROM cruises;
-- All ships sailing on the 17th:


/* -----------------------------------------------------------------------------
  IS NULL - p 183-184
    Can't use = with tests for null values
------------------------------------------------------------------------------*/


/* -----------------------------------------------------------------------------
  Sort rows using the order by clause - pp 184-194 
------------------------------------------------------------------------------*/
-- use books
DROP TABLE testsort;
CREATE TABLE testsort (
  sort_id      NUMBER PRIMARY KEY,
  value_type   VARCHAR2(15),
  sort_val     VARCHAR2(6)
);

BEGIN
  INSERT INTO testsort VALUES(1, 'STRING', '12');
  INSERT INTO testsort VALUES(2, 'STRING', '1');
  INSERT INTO testsort VALUES(3, 'STRING', '02');
  INSERT INTO testsort VALUES(4, 'STRING', '21');
  INSERT INTO testsort VALUES(5, 'STRING', '2');
  INSERT INTO testsort VALUES(6, 'STRING', '1.3');
  INSERT INTO testsort VALUES(7, 'STRING', '10');
  INSERT INTO testsort VALUES(8, 'STRING', 'APPLE');
  INSERT INTO testsort VALUES(9, 'STRING', 'apple');
  INSERT INTO testsort VALUES(10, 'STRING', 'Ape');
  INSERT INTO testsort VALUES(11, 'STRING', 'a');
  INSERT INTO testsort VALUES(12, 'Space', ' ');
  INSERT INTO testsort VALUES(13, 'STRING', 'null');
  INSERT INTO testsort VALUES(14, 'STRING', 'NULL');
  INSERT INTO testsort VALUES(15, 'Empty String', '');
  INSERT INTO testsort VALUES(16, 'STRING', '100');
  -- Numbers are converted to varchar2 automatically
  INSERT INTO testsort VALUES(17, 'NUMBER', 10);
  INSERT INTO testsort VALUES(18, 'NUMBER', 2);
  INSERT INTO testsort VALUES(19, 'NUMBER', 1);
  INSERT INTO testsort VALUES(20, 'NUMBER', 100);
  INSERT INTO testsort VALUES(21, 'NUMBER', 2.1);
  INSERT INTO testsort VALUES(22, 'NULL', null);
  INSERT INTO testsort VALUES(23, 'NULL', NULL);
  INSERT INTO testsort VALUES(24, 'STRING', '(null)');
  INSERT INTO testsort VALUES(25, 'STRING', '(NULL)');
  COMMIT;
END;
/

SELECT * FROM testsort;
-- use cruises
SELECT * FROM ports;
-- reference by column name
-- reference by postion

-- ASC is the default

-- Cant do this because it is using the select list, not the default list

-- Using column names is better than using reference by position

-- Can still use capacity for sort even if not displayed

-- We can also use expressions for sorting
SELECT * FROM projects;
-- Cannot use reference by position when doing math expressions
-- no syntax error, but doesn't order the way we expect

-- using an alias for sorting
-- AS is optional

-- Cannot use alias in WHERE, GROUP BY or HAVING clauses
  
-- =============================================================================
-- Bonus material
-- =============================================================================
-- books schema
SELECT * FROM ORDERS ORDER BY SHIPDATE;
SELECT * FROM ORDERS WHERE SHIPDATE IS NOT NULL;
SELECT * FROM ORDERS WHERE SHIPDATE IS NULL;

SELECT * FROM customers WHERE 1=1;
SELECT DISTINCT LASTNAME FROM CUSTOMERS;
SELECT lastname FROM customers
  WHERE lastname LIKE 'C%';

SELECT * FROM BOOKS
  WHERE CATEGORY = 'FAMILY LIFE' OR PUBID = 4 AND COST > 15;
  
SELECT * FROM BOOKS
  WHERE CATEGORY = 'FAMILY LIFE' OR (PUBID = 4 AND COST > 15);

SELECT * FROM BOOKS
    WHERE CATEGORY LIKE 'FAM%' OR pubid = 4  AND COST >15;
    
SELECT SHIPCITY, SHIPSTATE FROM ORDERS
    WHERE SHIPCITY IN ('AUSTIN', 'ATLANTA', 'BOISE');
    
SELECT SHIPCITY, SHIPSTATE FROM ORDERS
  WHERE SHIPCITY LIKE '_A%';
  
-- =============================================================================
-- Exercises
-- =============================================================================
-- 1.Return port_id, port_name, capacity for ports that start with 
--  either "San" or "Grand" and have a capacity of 4.

-- 2. Return vendor_id, name, and category where the category is 
-- 'supplier', 'subcontractor' or ends with 'partner'.

-- 3. Return room_number and style from ship_cabins
-- where there is no window or the balcony_sq_ft = null;
  
--4. Return ship_id, ship_name, capacity, length from ships 
-- where 2052 <= capacity <= 3000 and the length is either 100 or 855
