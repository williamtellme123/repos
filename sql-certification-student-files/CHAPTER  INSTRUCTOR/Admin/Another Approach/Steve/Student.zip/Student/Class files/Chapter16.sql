-- =============================================================================
-- Chapter 16 Hierarchical Retrieval
-- =============================================================================
/* -----------------------------------------------------------------------------
  Hierarchical query is a self join using the CONNECT BY clause
    Node - a connecting point
    Root node - the starting point
    Leaf node - a node that has no children
    LEVEL - identifies the generation from the root
    start with is optional, but without returns every possible line
-----------------------------------------------------------------------------*/
-- use cruises
SELECT * FROM employee_chart;

-- pseudocolumn LEVEL requires the CONNECT BY clause
SELECT LEVEL, employee_id, title, reports_to 
  FROM employee_chart
  -- START WITH indicates the root node for the query
  START WITH employee_id = 1
  -- CONNECT BY defines the self join relationship
  CONNECT BY PRIOR employee_id = reports_to;
    
/* -----------------------------------------------------------------------------
  TREE STRUCTURED REPORT - p 621
    Formatting the output to make it more readable
------------------------------------------------------------------------------*/

/* -----------------------------------------------------------------------------
  Choosing direction - p 622
    Direction of hierarchy is controlled by CONNECT BY PRIOR clause
    Top down uses PRIOR on PRIMARY KEY
    Bottom up uses PRIOR on FOREIGN KEY
------------------------------------------------------------------------------*/
-- TOP DOWN Connect by "PRIOR Low to High",
-- PRIOR on left on PRIMARY KEY (employee_id) side
SELECT LEVEL, employee_id, lpad(' ', LEVEL*2) || title title, reports_to
  FROM employee_chart START WITH employee_id = 1 
  CONNECT BY PRIOR employee_id = reports_to;

-- TOP DOWN Connect by "High to Prior Low", 
-- PRIOR on right on PRIMARY KEY (employee_id) side
        
-- BOTTOM UP Connect by "Prior High to Low"
-- PRIOR on left on FOREIGN KEY (reports_to) side

-- BOTTOM UP Connect by "Low to Prior High"
-- PRIOR on right on FOREIGN KEY (reports_to) side

/* -----------------------------------------------------------------------------
  ORDER SIBLINGS BY - p 623-4
------------------------------------------------------------------------------*/
-- Be careful with ORDER BY. Does this show the correct lineage?
SELECT LEVEL, employee_id, title, reports_to
  FROM employee_chart START WITH employee_id = 1 
  CONNECT BY PRIOR employee_id = reports_to
  ORDER BY title;

-- page 624 THIS SHOWS REPORTS IN CORRECT LINEAGE
SELECT LEVEL, reports_to, employee_id, LPAD(' ', LEVEL*2) || title title_up 
  FROM employee_chart
  START WITH employee_id = 1 CONNECT BY reports_to  = PRIOR employee_id
  ORDER SIBLINGS BY title;

/* -----------------------------------------------------------------------------
  SYS_CONNECT_BY_PATH(expr, c1) - p 624-5
    expr is the value to be displayed in the path
    c1 is the separating character
------------------------------------------------------------------------------*/
SELECT LEVEL, employee_id, sys_connect_by_path(title,'/') title 
  FROM employee_chart START WITH employee_id = 1 
  CONNECT BY reports_to  = PRIOR employee_id;
  

-- top down displays path from top
-- top to bottom: PRIOR on PK (employee_id) side

-- bottom up displays path from root to top
-- bottom up: PRIOR on FK (reports_to) side 


/* -----------------------------------------------------------------------------
  CONNECT_BY_ROOT Operator - p 625 bottom
  Can display any data from the root node
------------------------------------------------------------------------------*/
-- identifying root
  

-- bottom up identifying root

/* -----------------------------------------------------------------------------
  Excluding data - p 626-7
    Exclude individual rows using WHERE clause
    Exclude whole branches using the CONNECT BY clause
------------------------------------------------------------------------------*/
-- Look at query first without exclusion
SELECT LEVEL, employee_id,LPAD(' ', LEVEL*2) || title title 
  FROM employee_chart START WITH employee_id = 1 
  CONNECT BY reports_to = PRIOR employee_id;

-- removes single rows 
  
 -- removes whole branches
-- =============================================================================
-- Bonus material
-- =============================================================================
SELECT * FROM employee_chart;
SELECT LEVEL, employee_id, lpad('  ', LEVEL*2) || title title_formatted
    FROM employee_chart
    START WITH employee_id = 1
    CONNECT BY PRIOR employee_id = reports_to
    ORDER SIBLINGS BY title;

SELECT LEVEL, employee_id, lpad('  ', LEVEL*2) || title title_formatted
    FROM employee_chart
    START WITH employee_id = 9
    CONNECT BY PRIOR reports_to = employee_id
    ORDER SIBLINGS BY title;

SELECT LEVEL, employee_id, lpad('  ', LEVEL*2) || title title_formatted
    FROM employee_chart
    START WITH employee_id = 5
    CONNECT BY employee_id = PRIOR reports_to
    ORDER SIBLINGS BY title;

-- use books:
SELECT * FROM customers;
SELECT LEVEL, customer#, lastname, firstname, referred
  FROM customers -- WHERE referred IS NOT NULL
  START WITH customer# = 1003 CONNECT BY prior customer# = referred;
-- =============================================================================
-- STUDENT EXERCISES
-- =============================================================================
-- Add additional data to the employee_chart
INSERT INTO employee_chart VALUES (10, 'Chairman', NULL);
UPDATE employee_chart SET reports_to = 10 WHERE employee_id = 1;
INSERT INTO employee_chart VALUES (12, 'Board Member 2', 10);
INSERT INTO employee_chart VALUES (22, 'Ind Employee 8', 3);
INSERT INTO employee_chart VALUES (17, 'Manager 3', 7);

DESC employee_chart;

-- Is there anyone above the CEO?
  
-- What is the organization from the new root node?

-- What is the new organization if the VP leaves the company?

-- What is the new organization if the VP and staff are spun off?
