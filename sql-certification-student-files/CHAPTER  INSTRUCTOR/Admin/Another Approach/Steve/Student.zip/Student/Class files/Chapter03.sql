-- =============================================================================
-- Chapter 3 Manipulating Data
-- =============================================================================
/* -----------------------------------------------------------------------------
  DDL statements - page 94 - 96
------------------------------------------------------------------------------*/
-- use cruises
-- drop removes a database object
DROP TABLE ports2 CASCADE CONSTRAINTS;

-- CREATE creates or defines a database object

-- ALTER changes an existing database object

-- RENAME changes the name of a database object

-- COMMENT adds comments to the data dictionary for database objects
-- To delete a comment, just use an empty string:

-- PURGE removes database objects from the recylebin

/* -----------------------------------------------------------------------------
  Inserting rows into a table
  DML statements p97
-- page 98 - 106
------------------------------------------------------------------------------*/
SELECT * FROM cruises;
DESC cruises;
SELECT * FROM user_constraints WHERE table_name = 'CRUISES';
SELECT * FROM cruise_types;  -- id: 1-5
SELECT * FROM ships; -- ship_id 1-8
SELECT * FROM employees; -- employee_id: 1-7

SELECT * FROM ports;

SELECT * FROM ships;

SELECT * FROM positions;
COMMIT;

-- Type 1: all columns in default order, order must be the same as described
-- Default column list on p 99

-- Type 2: all columns listed, order doesn't matter
-- Enumerated column list listing all columns
  
-- Type 3: just some columns, order does not matter
-- Enumerated column list listing only some of the columns
  
SELECT * FROM cruises;

-- Will produce duplicate key:

-- Test what the current value is for our sequence generator:
-- Changes to next value even though previous insert failed

-- Delete Rows from a table page 111
-- Oracle database can do some autoconversion between certain datatypes

-- COMMIT is a TCL statement that saves all DML results to the database
-- ROLLBACK is a TCL statement that reverts uncommitted data to the
-- last COMMIT or autocommit.
SELECT * FROM cruises;



-- this rollback didn't remove Jamaica Bound because ALTER TABLE is 
-- a DDL command and does an autocommit

/* -----------------------------------------------------------------------------
  Update rows in a table - page 104 - 110
------------------------------------------------------------------------------*/
-- use cruises
select * from cruise_types;

/*
1	Day Cruise	1
2	Eastern Carribean	5
3	Western Carribean	3
4	Western Carribean	5
5	Transatlantic	10
*/

  
-- Updating multiple rows

-- Updating using an expression (p 108)

SELECT * FROM ships;


-- STUDENT EXERRCISE: use books
select * from books;
select * from books where category = 'COMPUTER';
-- mark down all the books in the computer category by 10%
-- put that sale value into retail_sale
-- mark down all other books by 1/2 the difference between the cost and retail


/* -----------------------------------------------------------------------------
  Delete Rows from a table - page 111
------------------------------------------------------------------------------*/
-- use books

/* -----------------------------------------------------------------------------
  Control transactions - page 112-122
    test the savepoint features of oracle
------------------------------------------------------------------------------*/
desc salary_chart;
/*
Name       Null Type         
---------- ---- ------------ 
ORG_ID          NUMBER(7)    
EMP_TITLE       VARCHAR2(30) 
EMP_INCOME      NUMBER(10,2) 
SUPERIOR        VARCHAR2(30) 
SUP_INCOME      NUMBER(10,2) 
*/
select * from salary_chart;
select * from user_constraints where table_name = 'SALARY_CHART';


-- SAVEPOINT provides an optional 'commit' marker in a session to which a 
-- rollback can restore the transaction to.

-- DDL command does implicit commit and wipes out previous savepoints:

-- Resetting the table to rerun the exercise
--alter table salary_chart drop column last_modified;

select * from salary_chart;

-- ============================================================================
-- BONUS MATERIAL
-- ============================================================================
SELECT * FROM employees;
INSERT INTO employees VALUES(101, 12, 'Jonas', 'Grumby', 1, null, '23-AUG-1924', null); -- Skipper
INSERT INTO employees VALUES(102, 12, 'Willy', 'Gilligan', 5, NULL, '21-FEB-1941', NULL);
INSERT INTO employees VALUES(201, 13, 'Merrill', 'Stubing', 1, null, null, null);
INSERT INTO employees VALUES(202, 13, 'Julie', 'McCoy', 2, null, null, null);
INSERT INTO employees VALUES(203, 13, 'Burl', 'Gopher', 10, NULL, NULL, NULL);
INSERT INTO employees VALUES(204, 13, 'Isaac', 'Washington', 5, null, null, null);
INSERT INTO employees VALUES(205, 13, 'Adam', 'Bricker', 3, NULL, NULL, NULL);
DELETE FROM employees WHERE employee_id > 500;

SELECT * FROM cruise_customers;
DELETE FROM cruise_customers;
ROLLBACK;
SELECT * FROM cruise_customers;
INSERT INTO cruise_customers VALUES( 101, 'Thurston', 'Howell');
INSERT INTO cruise_customers VALUES( 102, 'Eunice', 'Howell');
INSERT INTO cruise_customers VALUES( 103, 'MaryAnn', 'Summers');
INSERT INTO cruise_customers VALUES( 104, 'Ginger', 'Grant');
INSERT INTO cruise_customers VALUES( 105, 'Roy', 'Hinkley'); -- Professor
COMMIT;

SELECT * FROM ships;
SELECT * FROM employees;
SELECT * FROM cruises;
SELECT * FROM USER_CONS_COLUMNS WHERE TABLE_NAME = 'CRUISES';
SELECT * FROM USER_CONS_COLUMNS WHERE TABLE_NAME = 'EMPLOYEES';
SELECT * FROM USER_CONS_COLUMNS WHERE TABLE_NAME = 'CONTACT_EMAILS';
  INSERT INTO cruises (cruise_id, cruise_type_id, cruise_name, 
                       captain_id,  start_date, end_date, status)
   VALUES (seq_cruise_id.nextval, '1', 'Moon At Sea', 1, '02-JAN-10', '09-JAN-10', 'Sched');
  INSERT INTO cruises 
  VALUES (seq_cruise_id.nextval, '1', 'Whales At Sea', 8,1, '02-JAN-10', '09-JAN-10', 'Sched' );
  INSERT INTO cruises (cruise_id) VALUES (seq_cruise_id.nextval);
  SELECT * FROM cruises;
  DELETE FROM cruises;
  SELECT * FROM ships;
  UPDATE cruises SET ship_id = 8 WHERE cruise_id = 1;
  SELECT * FROM cruises;
  ROLLBACK;
  COMMIT;

-- ============================================================================
-- EXERCISES
-- ============================================================================
-- use books
-- 1. Look at the data in customers table
-- 2. Look at the structure of the customers table
-- 3. Insert a new customer using the default column list
-- 4. Insert a new customer using an enumerated list of all the columns
            
-- 5. Insert a new customer using an enumerated list of 
--    customer#, firstname and lastname

-- Bonita Morales changed her name to Gonzales and her address 
-- is now 16 School St in San Marcos amd her zip is now 67678

-- use a sequence in an insert statement
-- 1.find the maximum order# first
-- 2. create a sequence that starts with max+1
-- 3. use the sequence in an insert statement

-- use cruises
-- Update the start_date and end_dates of all the cruises to occur
-- 5 days later using an expression
