-- =============================================================================
-- Chpater 13 Generating Reports by Grouping Related Data
-- =============================================================================
/* -----------------------------------------------------------------------------
  Extensions to the GROUP BY clause: ROLLUP, CUBE, GROUPING SETS
    Aggregate
    Super Aggregate
------------------------------------------------------------------------------*/
-- using cruises
-- find some rows to deal with
SELECT ship_cabin_id, room_style, room_type, sq_ft
  FROM ship_cabins WHERE ship_cabin_id <= 9
  ORDER BY 1;

-- revisit the group by and aggregate functions
SELECT room_type, count(*), sum(sq_ft), round(avg(sq_ft)) avg_sqft
  FROM ship_cabins WHERE ship_cabin_id <= 9
  GROUP BY room_type;

/* -----------------------------------------------------------------------------
  Use ROLLUP to Produce Subtotal Values - page 512-5
    For rollups expect n+1 types of groupings
      ROLLUP one column  expect 1 + 1 = 2 types of groupings
      ROLLUP two columns : 2 + 1 is 3 types of groupings
------------------------------------------------------------------------------*/
-- rollup on one column produces two types of groupings, the aggregate
-- and the superaggregate
-- p 513 top 
  

-- ROLLUP two columns

-- rollup by ROOM_STYLE, ROOM_TYPE

-- reversing the groupings in a rollup

-- Formatting output using nvl

-- ROLLUP three columns: 3 + 1 produces four types of groupings
-- p 514
SELECT * FROM ship_cabins;
SELECT room_type, window, room_style, count(*), sum(sq_ft), round(avg(sq_ft)) avg_sqft, sum(guests)
  FROM ship_cabins WHERE ship_cabin_id <= 6
  GROUP BY window, room_type, room_style;


-- combining agregates with super agregates

-- Formatting output using nvl

/* -----------------------------------------------------------------------------
  Use CUBE to Produce Crosstabulation Values - pp 515-6
    For CUBE expect 2 to the nth power types of groupings
    Produces all possible combinations
------------------------------------------------------------------------------*/
-- CUBE one column looks like rollup, expect 2^1 = 2 types of groupings
-- CUBE two columns, expect 2^2 = 4 types of groupings
-- p 516

-- CUBE three columns, expect 2^3 = 8 types of groupings
-- cube by WINDOW, ROOM_TYPE,ROOM_STYLE
SELECT room_style, window, room_type, count(*), sum(sq_ft), round(avg(sq_ft)) avg_sqft, sum(guests)
  FROM ship_cabins WHERE ship_cabin_id <= 9
  GROUP BY CUBE (room_style, window, room_type);
-- 1 no superaggregate       17,18,23,25,26
-- 2 room_type               16,22,24
-- 3 window                  14,15,20,21
-- 4 room_style              6,8,9,11,12
-- 5 window, room_type       13,19
-- 6 window, room_style      2,3,4
-- 7 room_style, room_type   5,7,10
-- 8 all three               1



/* -----------------------------------------------------------------------------
  Use GROUPING function - pp 517-8
    returns 1 if a row is a superaggregate
    returns a 0 if a row is an aggregate
------------------------------------------------------------------------------*/
SELECT room_type, room_style, count(*), sum(sq_ft), grouping(room_type)
  FROM ship_cabins --WHERE ship_cabin_id <= 9
  GROUP BY ROLLUP (room_style, room_type);
  
SELECT room_type, room_style, count(*), sum(sq_ft), grouping(room_type)
  FROM ship_cabins --WHERE ship_cabin_id <= 9
  GROUP BY CUBE (room_style, room_type);

-- using grouping function on different groups

-- using grouping function for report formatting


/* -----------------------------------------------------------------------------
  Use GROUPING SETS - pp 519-21
    Allow us to specify how we want to group the data
    We only see the superaggregates
------------------------------------------------------------------------------*/
SELECT room_style, window, NULL, sum(sq_ft)
  FROM ship_cabins
  WHERE ship_cabin_id BETWEEN 3 AND 9
  GROUP BY room_style, window
UNION
SELECT NULL, NULL, room_type, sum(sq_ft)
  FROM ship_cabins
  WHERE ship_cabin_id BETWEEN 3 AND 9
  GROUP BY room_type;

-- three column

-- =============================================================================
-- Bonus material
-- =============================================================================
select nvl( decode (grouping(room_type),  -- 1st nvl parameter
                          1, upper(room_style),
                          room_style),
            'GRAND_TOTAL') as formatted_style, -- 2nd nvl parameter
        room_type, sum(sq_ft)
from ship_cabins where ship_cabin_id <= 9
group by rollup(room_style, room_type);

-- =============================================================================
-- EXERCISES
-- =============================================================================
-- page 517-518
-- -----------------------------------------------------------------------------

