-- =============================================================================
-- Chapter 9 Retrieving Data Using Subqueries
-- =============================================================================
/* -----------------------------------------------------------------------------
  Single Row Subqueries return a scalar result    p 350-353
    scalar result: single row, single column
------------------------------------------------------------------------------*/
-- cruises schema
SELECT * FROM employees;

-- Who are Alice Lindon's shipmates?
  
-- The inner query must return a scalar value if it is in an equal expression

-- There are two 'Smith's in the table so it is not a scalar result (single row, single column):
-- filter out Al Smith

select * from employees;

-- What projects cost more than any upgrade project
SELECT * FROM projects;

/* -----------------------------------------------------------------------------
  Multirow subquery - returns more than one row - p354
------------------------------------------------------------------------------*/
SELECT ship_id, first_name, last_name FROM employees WHERE last_name = 'Smith';

-- p 354 replace the = in line 22 with in
  
-- What employees have taken a cruise (are cruise customers)?
SELECT * FROM employees;
SELECT * FROM cruise_customers;
INSERT INTO cruise_customers VALUES (4, 'Buffy', 'Worthington');
INSERT INTO cruise_customers VALUES (5, 'Trish', 'West');
COMMIT;

-- This returns an employee that is not a cruise customer:
-- Solve problem using a multirow, multicolumn subquery

-- p 355 Practice comparison conditions from table 9-2
-- NOT used with IN to reverse the result
  
-- ALL used with >,<,>=,<=,!=, = returns TRUE if match found or NO ROWS, FALSE otherwise
-- What projects cost more than any upgrade project (using ALL)

-- ANY used with >,<,>=,<=,!=, = returns TRUE if match found with ANY in the list, FALSE otherwise
     
-- SOME is the same as ANY


/* -----------------------------------------------------------------------------
  Multicolumn subquery - p 356
    The multi-column list of the parent query is enclosed in paraenthesis
    columns are separated by commas
    datatypes of the columns must match
------------------------------------------------------------------------------*/
select * from cruise_customers;
select * from employees;

-- multi row, multi column
-- Are there any employees who have taken a cruise

SELECT * FROM pay_history;
SELECT * FROM invoices;
insert into invoices values (8, '04-JUN-01', 'x250', null, null, 45500, null);
-- multi row, multi column
  
/* -----------------------------------------------------------------------------
-- Where subqueries can be used
------------------------------------------------------------------------------*/
-- Type 1 subquery in the SELECT clause
-- list of expressions aka columns or math or literals
-- this is a non-correlated sub query that returns one row/one column

-- Type 2 subquery in WHERE clause

-- What is the name of Joe Smith's captain?
-- Return the ship_id, cruise_id, the captains first and last name
SELECT * FROM cruises;
SELECT * FROM employees WHERE ship_id = 3;
  
SELECT * FROM employees;
SELECT * FROM positions;
-- How many captain_id's are not captains?

-- Type 3 subqueries in the FROM clause. They take the place of a table in the
-- FROM clause and must be given an alias. You can use any type of JOIN syntax
-- with these subueries

-- What are the 2 ports that have the largest capacity
select * from ports;

-- Return ship_name and port_name and capacity
-- for the ship with the maximum capacity in each home_port

-- run these for this exercise if they are not already in the database:
INSERT INTO cruise_orders VALUES (1, '04-JUN-10', '21-JUN-10', 1, 1);
INSERT INTO cruise_orders VALUES (2, '12-JUN-10', '01-JUL-10', 2, 1);
INSERT INTO cruise_orders VALUES (3, '21-JUN-10', '01-JUL-10', 3, 2);
INSERT INTO cruise_orders VALUES (4, '30-JUN-10', '10-JUL-10', 4, 1);
SELECT * FROM cruise_orders;

insert into ship_cabins 
  values (seq_ship_cabin_id.nextval, 2, 102, 'Suite', 'Standard', 'Balcony', 4, 525, 110);
insert into ship_cabins 
  values (seq_ship_cabin_id.nextval, 3, 102, 'Suite', 'Standard', 'Balcony', 4, 525, 110);
select * from ship_cabins;


-- This example is of two non-correlated sub queries in the from clause

-- Subqueries in the FROM clause take the place of a table and
-- may need an alias depending on which JOIN syntax you use

-- same example using JOIN ON syntax (requires table aliases)  
  
-- same example using old style syntax

-- Update 
-- Promote employees to captain

-- p 359 scalar subquery in an insert statement in the values clause
SELECT * FROM ships;
SELECT * from POSITIONS;
INSERT INTO positions VALUES (11, 'Bartender', 6, null, null, null);
COMMIT;

/* -----------------------------------------------------------------------------
  CORRELATED SUBQUERIES are queries that are integrated with the parent query
    1. outer query runs to the first row
    2. the outer query passes room style to the inner query
    3. the inner query runs once
    4. the inner query returns the result to the outer query
    5. the outer query then completes the first row
    6. the outer query continues with the second row
------------------------------------------------------------------------------*/
-- Create a single query that lists all the cabins in the ship whose size
-- is larger than the average cabin FOR ITS ROOM_STYLE (p 360)
    

-- Create a single query that lists all the rooms where the sq_ft is the
-- smallest for each room style
  
-- EXERCISE: Return all columns from ship cabins that have larger than average
-- balcony sizes for each room_type and room_style

-- another correlated inner query

-- STUDENT EXERCISE: What employees have worked the longest on each ship?
/* -----------------------------------------------------------------------------
  Updating using correlated subqueries - p 363
------------------------------------------------------------------------------*/

-- give a 10% discount to whoever placed the single biggest 
-- invoice in that quarter
  
-- In a delete statement

-- removes the rooms with the smallest balcony for each combination of
-- room_style and room_type



/* -----------------------------------------------------------------------------
  Exists and not exists operators - p 365
    EXISTS tests for the existance of any rows in a subquery and returns TRUE
        if there are.
    EXISTS subqueries are sometimes referred to as semijoins
------------------------------------------------------------------------------*/
select * from ports;
select * from ships;
-- This returns ports where at least one ship calls this port its home port
-- We are correlating the outer query using p1 with the inner query using s1
                

-- Returns information from ports which have a ship home ported there


-- Return port information for ports without a ship home ported there


/* -----------------------------------------------------------------------------
  Use the WITH clause to assign a name to a subquery block - p 366
    Considered a clause of the SELECT statement
    Comes before the SELECT keyword
------------------------------------------------------------------------------*/

SELECT * FROM ports;

/* -----------------------------------------------------------------------------
  Multilevel subqueries
------------------------------------------------------------------------------*/
-- books schema

-- Inner queries run before outer queries

-- Three levels  

-- Four levels

-- =============================================================================
-- Bonus material
-- =============================================================================
-- Question 9
select * from work_history;
select employee_id from work_history w1
  where ABS(start_date - end_date) <= ALL
    (select min(abs(start_date - end_date))
      from work_history where ship_id = w1.ship_id);

-- Question 10
SELECT s1.ship_name, capacity, 
  (SELECT port_name FROM ports WHERE port_id = s1.home_port_id) home_port
  FROM ships s1  WHERE s1.capacity = 
    (SELECT MIN(capacity) FROM ships s2 WHERE s2.home_port_id = s1.home_port_id);
                      

-- test count
SELECT b.title,b.isbn, SUM(quantity) qty
  FROM orderitems oi, books b WHERE oi.isbn = b.isbn
  GROUP BY b.title,b.isbn;
-- test author
SELECT title,lname,fname FROM books b, bookauthor ba, author A
  WHERE b.isbn = ba.isbn AND ba.authorid = A.authorid;

-- How many customers purchased books 
-- written/co-written by James Austin
-- books written by James Austin
SELECT DISTINCT b.isbn
  FROM books b, bookauthor ba, author A
  WHERE ba.isbn = b.isbn AND ba.authorid = A.authorid
    AND lname = 'AUSTIN' AND fname = 'JAMES';

SELECT COUNT (DISTINCT customer#)
  FROM orders o, orderitems oi
  WHERE o.order# = oi.order# AND oi.isbn IN
    (SELECT DISTINCT b.isbn
       FROM books b, bookauthor ba, author A
       WHERE ba.isbn = b.isbn AND ba.authorid = a.authorid
         AND lname = 'AUSTIN' AND fname = 'JAMES');
      
                    
-- Increase the retail value by 10% of all books that where the retail value is
-- less than the average of the books in that category
UPDATE books b SET retail = retail * 1.1
    WHERE b.retail <= (SELECT avg(retail) FROM books
                    WHERE CATEGORY = b.CATEGORY);
ROLLBACK;
-- ============================================================================
-- EXERCISES
-- ============================================================================
-- 9-1 Determine the books title, retail, category
-- that are < avg retail of books in the same category
              
-- 9-2 Who purchased least expensive book(s)
              
-- 9-3 Which books by same publisher as 'The Wok Way to Cook'

-- 9-4 return  first and last name of author(s)
-- who wrote the least (most) frequently purchased book
  
-- 9-5 Return firstname, lastname, order# of those orders where the
-- shipped to state is the same as Order 1014

-- 9-6 return the order# of those orders with a total > order 1008
-- step 1: write an inner query to return sum of order# 1008
-- step 2: write a sql query that gives a total for each order
-- return the order# and the total order value
-- step 3 put them together
                               
-- 9-7 Create a correlated subquery in select clause for books
-- that calculates the category average retail

-- 9-8 Use a correlated subquery to find books that cost < than other books 
-- in same category using the lowest or cheapest retail value in each category

-- 9-9 find the 2 most expensive books

-- 9-10 List all titles in same cat customer 1007 purchased. 
-- Do not include titles purchased by customer 1007.
          
-- 9-11 Customer# with city and state that had longest shipping delay
