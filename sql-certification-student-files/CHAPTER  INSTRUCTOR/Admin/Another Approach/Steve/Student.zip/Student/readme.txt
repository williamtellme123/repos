Instructions for setting up class computers

1.  Copy folder oracleclass to c:\oracleclass
2.	Unzip (extract) OracleXE112_WinZip32.zip into c:\oracleclass\OracleXE112_WinZip32\
3.	Create folder c:\oraclexe
4.	Browse to find c:\oracleclass\OracleXE112_WinZip32\Disk1\Setup.exe
5.	Right-Click on Setup.exe
6.	Choose Run as Administrator
7.	Confirm it is installing into C:\oraclexe
8.	Defaults: TNS port 1521, MTS Port 2030, HTTP Port 8081
9.	IMPORTANT: WHEN PROMPTED FOR A PASSWORD ENTER> admin
10.	Reboot
11. Find icon on desktop: Get Started with Oracle 11g Express Edition > Click to launch 
12. Browser will start and display Oracle XE 11.2
13. Close Browser
14. Find c:\oracleclass\sqldeveloper\sqldeveloper.exe
15. Right click on the sqldeveloper.exe file. Select send to desktop (create shortcut)
16. Launch SQL Developer
17. Right click on Connections, select New Connection
18. In dialog Connection Name is �system�, 
			  Username is �system�
			  Password is �admin�
19. Click the save password checkbox		
20. Click Test, if success, click Connect
21. In the system window that opens up, type the following:
		create user books identified by books;
				result should be 'user books create'
		grant all privileges to books;
				result should be 'grant succeeded'
		create user cruises identified by cruises;
				result should be 'user books create'
		grant all privileges to cruises;
				result should be 'grant succeeded'
22. Right click on Connections, select New Connection
23. In dialog Connection Name is �books�, 
			  Username is �books�
			  Password is �books�
24. Click the save password checkbox		
25. Click Test, if success, click Connect
26. Right click on Connections, select New Connection
27. In dialog Connection Name is �books�, 
			  Username is �books�
			  Password is �books�
28. Click the save password checkbox		
29. Click Test, if success, click Connect

