drop user books cascade;
create user books identified by books;
grant all privileges to books;

create user cruises identified by cruises;
grant all privileges to cruises;




























create user steve identified by clarinet;
grant all privileges to steve;

create user geography identified by javatest;
grant create session to geography;
grant unlimited tablespace to geography;
grant select any table to geography;

