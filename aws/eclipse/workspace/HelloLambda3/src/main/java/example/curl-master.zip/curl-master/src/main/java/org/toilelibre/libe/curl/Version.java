package org.toilelibre.libe.curl;
public final class Version {
 public static String VERSION = "0.0.10-SNAPSHOT";
 public static String BUILD_TIME = "2017-02-23T20:21:47Z";
}
