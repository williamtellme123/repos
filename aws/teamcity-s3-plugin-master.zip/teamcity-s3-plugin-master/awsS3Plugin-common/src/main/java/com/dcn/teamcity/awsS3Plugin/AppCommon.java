package com.dcn.teamcity.awsS3Plugin;

public class AppCommon {
}
